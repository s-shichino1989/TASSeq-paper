#' background_subtraction_Biex_wrapper
#'
#' Internal function to detect backgorund count thresholds for each gene based on
#' gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of count data of each gene
#' are automatically determined by flowTrans package.
#'
#' @param x A sparse matrix of genes/cells count data
#' @param y rowname or rownumber of which is processed
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak
#' @param iteration A maximum number of iteration for EM process
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package.
#' @param flooring A cutoff value of gene count. default=0
#' @param dir.name An output directory name for generate count threshold plots-containing folder. Default is current working directory.
#' @param seed A random seed.
#'
#'
#' @rdname background_subtraction_Biex_wrapper
#' @return threshold count (raw count), single numeric value
#' @export

background_subtraction_Biex_wrapper = function(x,
                                               y,
                                               modelnames="E",
                                               min.ave=6,
                                               min.diff=5.5,
                                               flooring=0,
                                               uncert.thre=0.25,
                                               iteration=3000,
                                               dir.name="./",
                                               seed = seed
                                               ) {

  #apply biexponential-transformation against raw count data
  data1 = x[y,,drop=F]
  data1 = as.matrix(x[y,,drop=F])
  data2 = data1+1
  data1 = cbind(t(data1), t(data2))
  colnames(data1) = c("A", "B")
  data1 = data1[data1[,1]>flooring,,drop=F]
  data1 = data1[order(data1[,1]),,drop=F]
  set.seed(seed)
  fuga = flowCore::flowFrame(as.matrix(data1))
  fuga = try(flowTrans::flowTrans(fuga,"mclMultivBiexp", c("A", "B"), n2f=FALSE,parameters.only=FALSE), silent = TRUE)
  if (class(fuga) != "try-error" && class(fuga) != "NULL") {
    fuga = cbind(flowCore::exprs(fuga$result)[,1], data1[,1])
  } else {
    fuga = cbind(log2(data1[,1]+1), data1[,1])
  }
  data1 = fuga[,1]

  #temporary set thre object
  thre="thre"

  #mclust::mclust.options(subset=FALSE)
  data2 = try(mclust::Mclust(data1, G=1:3,
                             modelNames=modelnames,
                             control = mclust::emControl(itmax=iteration)),
              silent = TRUE)
  if (class(data2) != "try-error" && class(data2) != "NULL" && data2$G == 3) {
    data2_mean = rbind(data2$parameters$mean, data2$parameters$variance$sigmasq)
    data2_mean = data2_mean[,order(data2_mean[1,])]
    data2_sigmasq = data2_mean[2,]
    data2_mean = data2_mean[1,]
    t = abs(stats::qt(0.05/2, length(data2)-1)) #t statistics of 95% CI
    data2_classification = cbind(data1, data2$classification, data2$uncertainty)
    colnames(data2_classification) = c("count", "cluster", "uncertainty")
    data2_classification = as.data.frame(data2_classification)
    data2_mean_raw3 = fuga[fuga[,1]<data2_mean[3],,drop=F]
    data2_mean_raw3 = log2(max(as.numeric(data2_mean_raw3[,2]))+1)
    data2_mean_raw2 = fuga[fuga[,1]<data2_mean[2],,drop=F]
    data2_mean_raw1 = fuga[fuga[,1]<data2_mean[1],,drop=F]
    data2_abs1 = data2_mean_raw3 - log2(max(as.numeric(data2_mean_raw1[,2]))+1)
    data2_abs2 = data2_mean_raw3 - log2(max(as.numeric(data2_mean_raw2[,2]))+1)

    if (data2_mean_raw3 >= min.ave && data2_abs2 >=min.diff){
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[2],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[3] - t * data2_sigmasq[3]
      upper = data2_mean[2] + t * data2_sigmasq[2]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    } else if (data2_mean_raw3 >= min.ave && data2_abs1 >=min.diff){
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[3] - t * data2_sigmasq[3]
      upper = data2_mean[1] + t * data2_sigmasq[1]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    }
  } else if (class(data2) != "try-error" && class(data2) != "NULL" && data2$G == 2) {
    data2_mean = rbind(data2$parameters$mean, data2$parameters$variance$sigmasq)
    data2_mean = data2_mean[,order(data2_mean[1,])]
    data2_sigmasq = data2_mean[2,]
    data2_mean = data2_mean[1,]
    t = abs(stats::qt(0.05/2, length(data2)-1)) #t statistics of 95% CI
    data2_classification = cbind(data1, data2$classification, data2$uncertainty)
    colnames(data2_classification) = c("count", "cluster", "uncertainty")
    data2_classification = as.data.frame(data2_classification)
    data2_mean_raw2 = fuga[fuga[,1]<data2_mean[2],,drop=F]
    data2_mean_raw2 = log2(max(as.numeric(data2_mean_raw2[,2]))+1)
    data2_mean_raw1 = fuga[fuga[,1]<data2_mean[1],,drop=F]
    data2_mean_raw1 = log2(max(as.numeric(data2_mean_raw1[,2]))+1)
    if (data2_mean_raw2 >= min.ave && data2_mean_raw2-data2_mean_raw1 >= min.diff) {
      #if 2-component gaussian mixture
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[2] - t * data2_sigmasq[2]
      upper = data2_mean[1] + t * data2_sigmasq[1]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    }
  }
  #visulalize Biexponential-transformed count distribution and its threshold
  if (thre != "thre") {
    file.name = sprintf("%s.png", rownames(x)[y])
    file.name = paste(dir.name, "/", file.name, sep='')
    grDevices::png(file.name, width = 512, height = 512)
    MASS::truehist(fuga[,1], col = "#00ffff80", border="#00ffff80",xlab = "biex-transformed-count(log2)", ylab = "Density",
                   main=as.character(rownames(x)[y]), xlim = c(ceiling(min(fuga[,1])), ceiling(max(fuga[,1]))), ylim =c(0,1))
    graphics::rug(fuga[,1], lwd=0.3)
    graphics::lines(stats::density(fuga[,1]), type="l", col = "#0000ff80", lwd=2)
    graphics::abline(v=thre, col="red", lwd=3)
    grDevices::dev.off()
  }

  #convert Biex-transformed threshold to original count value
  if(thre != "thre"){
    thre = fuga[fuga[,1]<=thre,,drop=F]
    thre = max(as.numeric(thre[,2]))
  } else {thre=0}
  return(thre)
}

#' DBEC_figureDraw
#'
#' Internal function to draw concatenated DBEC filters
#'
#' @param x A sparse matrix of genes/cells count data
#' @param j rownumber of matrix
#' @param dir.name An output directory name for generate count threshold plots-containing folder. Default is current working directory.
#' @param DBEC_threshold A DBEC threshold value containing data frame
#'
#'
#' @rdname DBEC_figureDraw
#' @return only graphics output
#' @export

DBEC_figureDraw = function(x,
                           j,
                           dir.name,
                           DBEC_threshold){
  file.name = sprintf("%s.png", rownames(x)[j])
  file.name = paste(dir.name, "/", file.name, sep='')
  grDevices::png(file.name, width = 512, height = 512)
  tmp = x[j,]
  tmp = as.numeric(tmp)
  tmp = tmp[tmp>0]
  tmp = tmp + 1
  tmp = log2(tmp)
  if(length(tmp)>10){
  MASS::truehist(tmp, col = "#00ffff80", border="#00ffff80", h=0.5, xlab = "log2(x+1) count", ylab = "Density",
                 main=as.character(rownames(x)[j]), xlim =c(0, ceiling(max(tmp))), ylim =c(0,1))
  graphics::rug(tmp, lwd=0.3)
  graphics::lines(stats::density(tmp), type="l", col = "#0000ff80", lwd=2)
  graphics::abline(v=log2(DBEC_threshold[rownames(x)[j],]+1), col="red", lwd=3)
  grDevices::dev.off()
  }
}
