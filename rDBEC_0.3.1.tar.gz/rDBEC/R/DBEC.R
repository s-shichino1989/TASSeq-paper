utils::globalVariables(names = c("c", "j", "i", "gene.dispersion"),
                       package = 'rDBEC',
                       add = TRUE)
#' background_subtraction_Biex
#'
#' Main function to detect backgorund count thresholds for each gene based on
#' gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of each gene are automatically determined by flowTrans package.
#'
#' @param x A list of genes/cells mcount data (sparse matrix). The list must be named by sample IDs.
#' @param min.event A minimum number of cells that express each gene for background subtraction
#' @param minimum.max.expr A minimum of maximum expression of each gene for background subtraction
#' @param species A names of species for analyzed. Acceptable is hsa or mmu.
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak. If auto-threshold valus is unfer this value, set min.ave as user-supplied value.
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak. If auto-threshold valus is unfer this value, set min.ave as user-supplied value.
#' @param iteration A maximum number of iterations for mclust
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package
#' @param flooring A cutoff value of gene count. default=0
#' @param nthreads A number of workers. default is detectCores()/2
#' @param sample.name A character vector of sample name list
#' @param dir.name output directory of DBEC-correction figures (default: ./)
#' @param seed A random seed
#'
#' @importFrom stats complete.cases qt density quantile median
#' @importFrom dplyr full_join top_n
#' @importFrom magrittr %>%
#' @importFrom Seurat CreateSeuratObject NormalizeData
#' @importFrom foreach %dopar%
#' @importFrom doRNG %dorng%
#' @import future
#' @import future.apply
#' @import doFuture
#'
#' @rdname background_subtraction_Biex
#' @return A DBEC threshold count table(raw count)
#' @export

background_subtraction_Biex = function(x,
                                       min.event=100,
                                       minimum.max.expr=8,
                                       species="hsa",
                                       min.ave=6.0,
                                       min.diff=5.5,
                                       modelnames="E",
                                       iteration=1000,
                                       flooring=0,
                                       uncert.thre=1,
                                       nthreads=parallel::detectCores()/2,
                                       sample.name,
                                       dir.name="./",
                                       seed = 42) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  if(sum(names(x) != sample.name)!=0){stop("x must be named by sample IDs as sample.name vector")}

  #ave_hvg=list()
  median_read_depth=list()

  for (i in 1:nsamples){
    #calculate median read depth of each dataset
    Nreads = Matrix::colSums(x[[i]], na.rm=TRUE)
    median_read_depth[[i]]=stats::median(Nreads, na.rm = T)

    folder_name = sprintf("DBEC_thresholds_%s", sample.name[i])
    dir.name1 = paste(dir.name, folder_name, sep="")
    if(file.exists(dir.name1)==FALSE){dir.create(dir.name1)}

    tmp1 = qlcMatrix::rowMax(x[[i]])
    tmp1 = as.vector(tmp1)
    tmp2 = tmp1 >= 2^minimum.max.expr & apply(x[[i]], 1, function(z){sum(z>0)}) > min.event
    tmp2 = x[[i]][tmp2,]

    if (species == "hsa"){
      mito.genes = grep(pattern = "^MT.", x = rownames(x = tmp2), value = TRUE)
      ribo.genes = grep(pattern = "^RP[SL][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      riboRNA.genes = grep(pattern = "^RNA[[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      mask_gene = c(mito.genes, ribo.genes, riboRNA.genes, c("ACTB", "B2M", "GAPDH"))
    } else if (species == "mmu"){
      mito.genes = grep(pattern = "^mt.", x = rownames(x = tmp2), value = TRUE)
      ribo.genes = grep(pattern = "^Rp[sl][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      ribo.genes1 = grep(pattern = "^Rp[l][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      riboRNA.genes = c('Rn45s','Rn18s','Rn28s1','Rs5-8s1')
      mask_gene = c(mito.genes, ribo.genes, ribo.genes1, riboRNA.genes, c("Actb", "B2m", "Gapdh"))
    } else if (species == "rat"){
      mito.genes = grep(pattern = "^Mt.", x = rownames(x = tmp2), value = TRUE)
      ribo.genes = grep(pattern = "^Rp[sl][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      ribo.genes1 = grep(pattern = "^Rp[l][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      riboRNA.genes = c('Rn45s','Rn18s','Rn28s1','Rs5-8s1')
      mask_gene = c(mito.genes, ribo.genes, ribo.genes1, riboRNA.genes, c("Actb", "B2m", "Gapdh"))
    } else {stop("must specify valid species. Acceptable species are hsa or mmu or rat")}

    if(length(min.ave)>1){
      minimum_ave=min.ave[i]
    } else {minimum_ave=min.ave}
    if(length(min.diff)>1){
      min_diff=min.diff[i]
    } else {min_diff=min.diff}

    tmp2 = tmp2[setdiff(rownames(tmp2), mask_gene),]
    #calculate background thresholds
    cl = eval(parallelly::makeClusterPSOCK(workers=nthreads), envir=globalenv())
    environment(cl)=globalenv()
    eval(doParallel::registerDoParallel(cl, cores=nthreads), envir = globalenv())
    eval(doRNG::registerDoRNG(seed), envir=globalenv())

    res = eval(foreach::foreach (j = 1:nrow(tmp2),
                   .packages=c("mclust","Matrix","MASS", "flowTrans", "flowCore", "grDevices", "graphics", "stats"),
                   .multicombine=TRUE,
                   .maxcombine=nrow(tmp2),
                   .inorder=TRUE,
                   .noexport=setdiff(ls(),c("tmp2", "dir.name1", "background_subtraction_Biex_wrapper",
                                            "minimum_ave", "min_diff", "uncert.thre","flooring",
                                            "modelnames", "iteration", "seed")),
                   .options.RNG=seed
    ) %dopar% {
      background_subtraction_Biex_wrapper(tmp2,
                                          j,
                                          modelnames=modelnames,
                                          min.ave=minimum_ave,
                                          min.diff=min_diff,
                                          iteration=iteration,
                                          flooring=0,
                                          uncert.thre=uncert.thre,
                                          dir.name=dir.name1,
                                          seed = seed)
    }, envir = globalenv())
    parallel::stopCluster(cl)
    invisible(replicate(5, gc()))
    res = unlist(res, recursive = FALSE, use.names = FALSE)
    tmp3 = res != 0
    tmp4 = tmp2[tmp3,,drop=F] #DBEC mack data
    tmp5 = res[tmp3]   #DBEC threshold counts

    tmp6 = cbind(gene_short_name=rownames(tmp4), tmp5)
    colnames(tmp6)=c("gene_short_name", sample.name[i])

    #concatenate DBEC threshold count tables
    if (sample.name[i] == sample.name[1]) {
      DBEC_genes = tmp6
    } else {
      DBEC_genes = dplyr::full_join(as.data.frame(DBEC_genes), as.data.frame(tmp6), by = "gene_short_name")
      DBEC_genes = as.data.frame(DBEC_genes)
    }
    rm(tmp2)
    rm(tmp3)
    rm(tmp4)
    rm(tmp5)
    rm(tmp6)
    rm(res)
    invisible(replicate(5, gc()))
    message(paste("Finish sample ", sample.name[i], " processing", sep=""))
  }

  if (nsamples >1){
  #concatenate DBEC filter between samples
  message(paste("Concatenate DBEC filters...", sep=""))
  DBEC_genes=as.matrix(DBEC_genes)
  DBEC_genes1=as.data.frame(as.numeric(DBEC_genes[,2]), drop=F)
  colnames(DBEC_genes1)=sample.name[1]
    for (i in c(2:nsamples)){
      DBEC_genes1=cbind(DBEC_genes1,as.numeric(DBEC_genes[,i+1]))
      colnames(DBEC_genes1)[i]=sample.name[i]
    }
  #fill in NA values of DBEC filter
  rownames(DBEC_genes1)=DBEC_genes[,1]
  median_read_depth=unlist(median_read_depth)

  #set global DBEC filter as median of the threshold count of all of the datasets
  #DBEC filter thresholds were corrected by median read depth of the cells of each datasets
  res1 = apply(DBEC_genes1, 1, stats::median, na.rm=T)
  temp=median_read_depth
  temp_mean=mean(temp)
  temp=median_read_depth / temp_mean

  for (i in c(1:nsamples)){
    DBEC_genes1[,i] = ceiling(res1*temp[i])
  }
  res1 = as.data.frame(DBEC_genes1)

  for (i in c(1:nsamples)){
    folder_name = sprintf("DBEC_thresholds_%s", sample.name[i])
    dir.name1 = paste(dir.name, folder_name, sep="")
    expression_table = x[[i]][intersect(rownames(x[[i]]), rownames(res1)),]
    DBEC_thre_tmp = res1[intersect(rownames(x[[i]]), rownames(res1)),i,drop=F]
    #cl = parallelly::makeClusterPSOCK(workers=nthreads, autoStop = TRUE, useXDR=FALSE)
    #doParallel::registerDoParallel(cl, cores=nthreads)
    #doRNG::registerDoRNG(seed)
    res = foreach::foreach (j = 1:nrow(expression_table),
                            .packages=c("Matrix","MASS", "grDevices", "graphics", "stats", "rDBEC"),
                            .inorder=TRUE,
                            .noexport=setdiff(ls(),c("expression_table", "DBEC_thre_tmp", "dir.name1")),
                            .options.RNG=seed
    ) %dopar% {
      DBEC_figureDraw(x=expression_table, j, DBEC_threshold=DBEC_thre_tmp, dir.name=dir.name1)
    }
    #parallel::stopCluster(cl)
    gc()
  }

  } else {
  tmp=as.matrix(DBEC_genes)
  tmp1=as.numeric(DBEC_genes[,2])
  rownames(tmp)=tmp[,1]
  tmp=as.data.frame(tmp)
  tmp=cbind(tmp, tmp1)
  res1=tmp[,3,drop=F]
  colnames(res1)=sample.name[1]
  }

  return (res1)
}

utils::globalVariables(names = c("j", "i"),
                       package = 'rDBEC',
                       add = TRUE)
#' apply_DBEC_filter
#'
#' Main function for applying DBEC background subtraction against gees x cells read count matrix based on
#' gaussian mixture models of biexponential-transformed count distibution.
#'
#' @param x A list of genes/cells mcount data (sparse matrix).
#' @param DBEC_filter A DBEC_filter data frame generated by background_subtraction_Biex function
#' @param nthreads A number of workers
#' @param sample.name A character vector of sample name list
#' @param seed A random seed
#' @importFrom foreach %dopar%
#'
#' @rdname apply_DBEC_filter
#' @return A list of background-subtracted genes x cells count sparse matrix
#' @export
#'

apply_DBEC_filter = function(x,
                             DBEC_filter,
                             nthreads=parallel::detectCores()/2,
                             sample.name,
                             seed = 42) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) == sample.name) != nsamples){stop("x must be named by sample IDs as sample.name vector")}

  for (i in 1:nsamples){
    tmp2 = x[[i]][intersect(rownames(DBEC_filter), rownames(x[[i]])),]
    tmp3 = x[[i]][setdiff(rownames(x[[i]]), rownames(DBEC_filter)),]
    filter = DBEC_filter[intersect(rownames(DBEC_filter), rownames(x[[i]])),i]
    tmp2 = as.matrix(tmp2)

    #apply DBEC filter to read count matrix
    cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    doRNG::registerDoRNG(seed)
    res3 = foreach::foreach (j = c(1:nrow(tmp2)),
                    .final=data.table::rbindlist,
                    .packages=c("data.table"),
                    .inorder=TRUE,
                    .multicombine=TRUE,
                    .maxcombine=nrow(tmp2),
                    .noexport=setdiff(ls(),c("tmp2", "filter")),
                    .options.RNG=seed
    ) %dopar% {
      filtering(tmp2, j, filter)
    }
    parallel::stopCluster(cl)

    res3 = as.matrix(res3)
    res3 = Matrix::Matrix(res3, sparse = TRUE)
    res3 = rbind(res3, tmp3)
    rownames(res3) = c(rownames(tmp2),rownames(tmp3))
    colnames(res3) = colnames(x[[i]])
    tablelist[[i]]=res3
    rm(tmp2)
    rm(tmp3)
    rm(res3)
    invisible(replicate(5, gc()))
  }
  names(tablelist)=sample.name
  return(tablelist)
}


#' apply_DBEC_filter_scTCR
#'
#' Main function for applying DBEC background subtraction against gees x cells read count matrix based on
#' gaussian mixture models of biexponential-transformed count distibution.
#'
#' @param x A list of genes/cells mcount data (sparse matrix).
#' @param DBEC_filter A DBEC_filter data frame generated by background_subtraction_Biex function
#' @param nthreads A number of workers
#' @param sample.name A character vector of sample name list
#' @param seed A random seed
#'
#' @importFrom foreach %dopar%
#'
#' @rdname apply_DBEC_filter_scTCR
#' @return A list of background-subtracted genes x cells count sparse matrix
#' @export
#'

apply_DBEC_filter_scTCR = function(x,
                             DBEC_filter,
                             nthreads=parallel::detectCores()/2,
                             sample.name,
                             seed = 42) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) == sample.name) != nsamples){stop("x must be named by sample IDs as sample.name vector")}

  for (i in 1:nsamples){
    tmp2 = x[[i]][intersect(rownames(DBEC_filter), rownames(x[[i]])),]
    tmp3 = x[[i]][setdiff(rownames(x[[i]]), rownames(DBEC_filter)),]
    filter = DBEC_filter[intersect(rownames(DBEC_filter), rownames(x[[i]])),i]
    tmp2 = as.matrix(tmp2)

    #apply DBEC filter to read count matrix
    cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    doRNG::registerDoRNG(seed)
    res3 = foreach::foreach (j = c(1:ncol(tmp2)),
                             .final=dplyr::bind_cols,
                             .packages=c("dplyr"),
                             .inorder=TRUE,
                             .multicombine=TRUE,
                             .maxcombine=ncol(tmp2),
                             .noexport=setdiff(ls(),c("tmp2", "filter", "filtering_TCR")),
                             .options.RNG=seed
    ) %dopar% {
      filtering_TCR(tmp2, j, filter)
    }
    parallel::stopCluster(cl)

    res3 = as.matrix(res3)
    tmp3 = as.matrix(tmp3)
    res3 = rbind(res3, tmp3)
    rownames(res3) = c(rownames(tmp2),rownames(tmp3))
    colnames(res3) = colnames(x[[i]])
    res3=res3[,Matrix::colSums(res3, na.rm = TRUE)>0]
    tablelist[[i]]=as.data.frame(res3)
    rm(tmp2)
    rm(tmp3)
    rm(res3)
    invisible(replicate(5, gc()))
  }
  names(tablelist)=sample.name
  return(tablelist)
}

#' filtering
#'
#' Internal function for apply DBEC filter against read count matrix for parallel processing
#'
#' @param x A sparse matrix count data files
#' @param y rownumber of background-subtraction applying gene
#' @param DBEC_filter A DBEC_filter data frame
#'
#' @rdname filtering
#' @return A one-line numeric data frame
#'

filtering = function(x, y, DBEC_filter) {
  hoge = as.numeric(x[y,])
  hoge = replace(hoge,(hoge<=DBEC_filter[y]),0)
  names(hoge)=colnames(x)
  hoge=as.data.frame(hoge)
  hoge=t(hoge)
  hoge=as.data.frame(hoge)
  return(hoge)
}

#' filtering_TCR
#'
#' Internal function for apply DBEC filter against read count matrix for parallel processing
#'
#' @param x A sparse matrix count data files
#' @param y colnumber of background-subtraction applying TCR clone-count data
#' @param DBEC_filter A DBEC_filter data frame
#'
#' @rdname filtering_TCR
#' @return A one-column numeric data frame
#'

filtering_TCR = function(x, y, DBEC_filter) {
  hoge = x[,y]
  hoge[hoge!=max(hoge)] = replace(hoge[hoge!=max(hoge)],(hoge[hoge!=max(hoge)]<=DBEC_filter[hoge!=max(hoge)]),0)
  names(hoge)=rownames(x)
  hoge=as.data.frame(hoge)
  return(hoge)
}

#' filtering_NA
#'
#' Internal function for replace NA to mean threshold from DBEC filter table for parallel processing
#'
#' @param DBEC_filter A data frame of DBEC threshold counts
#' @param y rownumber of background-subtraction applying gene
#' @param DBEC_filter_mean A numeric vector of mean counts of DBEC thresholds.
#' @param median_read_depth A numeric vector of median read counts of the cells
#' @rdname filtering_NA
#' @return A one-line numeric data frame
#'

filtering_NA = function(DBEC_filter, y, DBEC_filter_mean, median_read_depth) {
  hoge = as.numeric(DBEC_filter[y,])
  DBEC_filter_median = stats::median(hoge)
  temp_mean=mean(median_read_depth)
  temp=median_read_depth / temp_mean
  hoge = replace(hoge,is.na(hoge), (temp*DBEC_filter_median)[is.na(hoge)])
  names(hoge)=colnames(DBEC_filter)
  hoge=as.data.frame(hoge)
  hoge=t(hoge)
  hoge=as.data.frame(hoge)
  return(hoge)
}
