utils::globalVariables(names = c("c", "j", "i", "gene.dispersion"),
                       package = 'rDBEC',
                       add = TRUE)
#' background_subtraction_Biex
#'
#' Main function to detect backgorund count thresholds for each gene based on
#' gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of each gene are automatically determined by flowTrans package.
#'
#' @param x A list of genes/cells mcount data (sparse matrix). The list must be named by sample IDs.
#' @param min.event A minimum number of cells that express each gene for background subtraction
#' @param minimum.max.expr A minimum of maximum expression of each gene for background subtraction
#' @param species A names of species for analyzed. Acceptable is hsa or mmu.
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak. If auto-threshold valus is unfer this value, set min.ave as user-supplied value.
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak. If auto-threshold valus is unfer this value, set min.ave as user-supplied value.
#' @param iteration A maximum number of iterations for mclust
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package
#' @param flooring A cutoff value of gene count. default=0
#' @param AutoThreshold Logical. Automatically set min.ave and min.diff by using count distribution of highly-variable genes of each datasets.
#' @param AutoThreshold_nGenes A number of high-variable genes (defined by Seurat FindVariableGenes function) for setting min.ave and min.diff automatically. default=300
#' @param AutoThreshold_quantile Quantile breaks for setting auto-threshold values for min.ave and amin.diff, default=0.25(lower quantile).
#' @param AutoThreshold_scale_factor A scale factor for selection of high-variable genes. default=1000000
#' @param mean.cutoff Bottom cutoff on mean expression for identifying variable genes
#' @param dispersion.cutoff Bottom cutoff on dispersion of expression for identifying variable genes
#' @param nthreads A number of workers. default is detectCores()/2
#' @param sample.name A character vector of sample name list
#' @param dir.name output directory of DBEC-correction figures (default: ./)
#'
#' @import doParallel
#' @import parallel
#' @import foreach
#' @importFrom data.table rbindlist
#' @importFrom Matrix rowMeans colMeans
#' @importFrom qlcMatrix rowMax
#' @importFrom stats complete.cases qt density quantile
#' @importFrom dplyr full_join top_n
#' @importFrom magrittr %>%
#' @importFrom Seurat CreateSeuratObject NormalizeData
#' @importFrom mclust Mclust
#' @importFrom MASS truehist
#' @importFrom flowTrans flowTrans
#' @importFrom flowCore flowFrame
#' @import grDevices
#' @import graphics
#'
#' @rdname background_subtraction_Biex
#' @return A DBEC threshold count table(raw count)
#' @export

background_subtraction_Biex = function(x,
                                       min.event=100,
                                       minimum.max.expr=7,
                                       species="hsa",
                                       AutoThreshold=TRUE,
                                       AutoThreshold_nGenes=300,
                                       AutoThreshold_quantile=0.25,
                                       AutoThreshold_scale_factor=1000000,
                                       mean.cutoff = 0.1,
                                       dispersion.cutoff = 0.5,
                                       min.ave=5.0,
                                       min.diff=4.0,
                                       modelnames="E",
                                       iteration=1000,
                                       flooring=0,
                                       uncert.thre=0.3,
                                       nthreads=parallel::detectCores()/2,
                                       sample.name,
                                       dir.name="./") {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) != sample.name)!=0){stop("x must be named by sample IDs as sample.name vector")}

  ave_hvg=list()

  for (i in 1:nsamples){

    folder_name = sprintf("DBEC_thresholds_%s", sample.name[i])
    dir.name1 = paste(dir.name, folder_name, sep="")
    if(file.exists(dir.name1)==FALSE){dir.create(dir.name1)}

    tmp1 = qlcMatrix::rowMax(x[[i]])
    tmp1 = as.vector(tmp1)
    tmp2 = tmp1 >= 2^minimum.max.expr & apply(x[[i]], 1, function(z){sum(z>0)}) > min.event
    tmp2 = x[[i]][tmp2,]

    if (species == "hsa"){
      mito.genes = grep(pattern = "^MT.", x = rownames(x = tmp2), value = TRUE)
      ribo.genes = grep(pattern = "^RP[SL][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      riboRNA.genes = grep(pattern = "^RNA[[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      mask_gene = c(mito.genes, ribo.genes, riboRNA.genes, c("ACTB", "B2M", "GAPDH"))
    } else if (species == "mmu"){
      mito.genes = grep(pattern = "^MT.", x = rownames(x = tmp2), value = TRUE)
      ribo.genes = grep(pattern = "^Rp[sl][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      ribo.genes1 = grep(pattern = "^Rp[l][[:digit:]]", x = rownames(x = tmp2), value = TRUE)
      riboRNA.genes = c('Rn45s','Rn18s','Rn28s1','Rs5-8s1')
      mask_gene = c(mito.genes, ribo.genes, ribo.genes1, riboRNA.genes, c("Actb", "B2m", "Gapdh"))
    } else {stop("must specify valid species. Acceptable species are hsa or mmu")}

    if(length(min.ave)>1){
      minimum_ave=min.ave[i]
    } else {minimum_ave=min.ave}
    if(length(min.diff)>1){
      min_diff=min.diff[i]
    } else {min_diff=min.diff}

    if (AutoThreshold){
      message("Detecting anchor values of DBEC threshold automatically...")
      seu = Seurat::CreateSeuratObject(tmp2)
      if (seu@version == "2.3.4"){
      seu = Seurat::NormalizeData(object = seu, scale.factor=AutoThreshold_scale_factor, display.progress=FALSE)
      seu = Seurat::FindVariableGenes(object = seu, x.low.cutoff = mean.cutoff,
                                                       x.high.cutoff = Inf,
                                      y.cutoff = dispersion.cutoff, do.plot=FALSE, display.progress=FALSE)
      var.genes = seu@var.genes
      seu = seu@hvg.info[var.genes,]
      seu = seu[rownames(seu) %in% rownames(tmp2),]
      seu = cbind(rownames(seu), seu)
      seu = seu %>% top_n(AutoThreshold_nGenes, gene.dispersion)
      seu = as.data.frame(seu)
      hvg_genes = as.character(seu[,1])
      } else if (seu@version >= "3.0"){
        seu = Seurat::NormalizeData(object = seu, scale.factor=AutoThreshold_scale_factor, verbose=FALSE)
        seu = Seurat::FindVariableFeatures(seu, selection.method = "vst", mean.cutoff = c(mean.cutoff, Inf),
                                   dispersion.cutoff = c(dispersion.cutoff, Inf),
                                   nfeatures = AutoThreshold_nGenes,  verbose=FALSE)
        hvg_genes = as.character(Seurat::VariableFeatures(seu))
      }
      rm(seu)
      gc()

      if (length(hvg_genes) >= 100){
      hvg_genes = tmp2[rownames(tmp2) %in% hvg_genes,]
      cl = parallel::makeCluster(nthreads, type="PSOCK", useXDR=FALSE)
      doParallel::registerDoParallel(cl)
      res = foreach (j = 1:nrow(hvg_genes),
                     .final=data.table::rbindlist,
                     .packages=c("data.table", "mclust","Matrix","MASS", "flowTrans", "flowCore", "grDevices", "graphics", "stats"),
                     .multicombine=TRUE,
                     .maxcombine=nrow(hvg_genes),
                     .inorder=TRUE,
                     .noexport=setdiff(ls(),c("hvg_genes", "DBEC_Biex_wrapper_hvg",
                                              "uncert.thre", "modelnames", "iteration"))
      ) %dopar% {
        DBEC_Biex_wrapper_hvg(hvg_genes,
                              j,
                              modelnames=modelnames,
                              iteration=iteration,
                              uncert.thre=uncert.thre)
      }
      parallel::stopCluster(cl)

      if(sum(is.na(res[,1]))!=nrow(res)){
      message("Successfully detect minimum average expression of hvg count")
      minimum_ave=as.numeric(quantile(res[,1], probs = seq(0,1, AutoThreshold_quantile), na.rm = TRUE))[2]
      if(minimum_ave<=min.ave){minimum_ave=min.ave}
      message(paste("minimum_ave=", minimum_ave, sep=""))
      ave_hvg[[i]]=minimum_ave
      }else{message(paste("failed automatic detection of DBEC min.ave, user-supplied values will use"))
      ave_hvg[[i]]=min.ave
      }
      if(sum(is.na(res[,2]))!=nrow(res)){
      message("Successfully detect minimum differnece between signal count and background count within hvg")
      min_diff=as.numeric(quantile(res[,2], probs = seq(0,1, AutoThreshold_quantile), na.rm = TRUE))[2]
       if(min_diff<=min.diff){min_diff=min.diff}
      message(paste("min.diff=", min_diff, sep=""))
      }else{message(paste("failed automatic detection of DBEC min.diff, user-supplied values will use"))}
    } else {message(paste("number of hvg is under 100, user-supplied thresholds will use"))}
    }

    tmp2 = tmp2[setdiff(rownames(tmp2), mask_gene),]
    #calculate background thresholds
    cl = parallel::makeCluster(nthreads, type="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    res = foreach (j = 1:nrow(tmp2),
                   .combine='c',
                   .packages=c("mclust","Matrix","MASS", "flowTrans", "flowCore", "grDevices", "graphics", "stats"),
                   .multicombine=TRUE,
                   .maxcombine=nrow(tmp2),
                   .inorder=TRUE,
                   .noexport=setdiff(ls(),c("tmp2", "dir.name1", "background_subtraction_Biex_wrapper",
                                            "minimum_ave", "min_diff", "uncert.thre","flooring",
                                            "modelnames", "iteration"))
    ) %dopar% {
      background_subtraction_Biex_wrapper(tmp2,
                                          j,
                                          modelnames=modelnames,
                                          min.ave=minimum_ave,
                                          min.diff=min_diff,
                                          iteration=iteration,
                                          flooring=0,
                                          uncert.thre=uncert.thre,
                                          dir.name=dir.name1)
    }
    parallel::stopCluster(cl)
    invisible(replicate(5, gc()))
    tmp3 = res != 0
    tmp4 = tmp2[tmp3,,drop=F] #DBEC mack data
    tmp5 = res[tmp3]   #DBEC threshold counts

    tmp6 = cbind(gene_short_name=rownames(tmp4), tmp5)
    colnames(tmp6)=c("gene_short_name", sample.name[i])

    #concatenate DBEC threshold count tables
    if (sample.name[i] == sample.name[1]) {
      DBEC_genes = tmp6
    } else {
      DBEC_genes = dplyr::full_join(as.data.frame(DBEC_genes), as.data.frame(tmp6), by = "gene_short_name")
      DBEC_genes = as.data.frame(DBEC_genes)
    }
    rm(tmp2)
    rm(tmp3)
    rm(tmp4)
    rm(tmp5)
    rm(tmp6)
    rm(res)
    invisible(replicate(5, gc()))
    message(paste("Finish sample ", sample.name[i], "processing", sep=""))
  }

  if (nsamples >1){
  #concatenate DBEC filter between samples
  DBEC_genes=as.matrix(DBEC_genes)
  DBEC_genes1=as.data.frame(as.numeric(DBEC_genes[,2]), drop=F)

  if (ncol(DBEC_genes) >= 3) {
    for (i in c(3:ncol(DBEC_genes))){
      DBEC_genes1=cbind(DBEC_genes1, as.numeric(DBEC_genes[,i]))
    }
  }
  #fill in NA values of DBEC filter
  rownames(DBEC_genes1)=DBEC_genes[,1]
  colnames(DBEC_genes1)=colnames(DBEC_genes)[2:ncol(DBEC_genes)]
  hogehoge=subset(DBEC_genes1, stats::complete.cases(DBEC_genes1)==T)
  fugafuga=subset(DBEC_genes1, stats::complete.cases(DBEC_genes1)==F)
  DBEC_filter_mean=ceiling(Matrix::rowMeans(fugafuga, na.rm=TRUE))
  ave_hvg=unlist(ave_hvg)
  cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
  doParallel::registerDoParallel(cl)
  res1 = foreach (j = c(1:nrow(fugafuga)), .final=data.table::rbindlist, .packages=c("data.table"),
                  .inorder=TRUE, .multicombine=TRUE, .maxcombine=nrow(fugafuga),
                  .noexport=setdiff(ls(),c("fugafuga", "DBEC_filter_mean", "ave_hvg", "filtering_NA"))) %dopar% {
                    filtering_NA(fugafuga, j, DBEC_filter_mean[j], ave_hvg)
                  }
  parallel::stopCluster(cl)

  res1 = as.matrix(res1)
  rownames(res1)=rownames(fugafuga)
  res1=rbind(res1, hogehoge)
  } else {
  tmp=as.matrix(DBEC_genes)
  tmp1=as.numeric(DBEC_genes[,2])
  rownames(tmp)=tmp[,1]
  tmp=as.data.frame(tmp)
  tmp=cbind(tmp, tmp1)
  res1=tmp[,3,drop=F]
  colnames(res1)=sample.name[1]
  }
  return (res1)
}

utils::globalVariables(names = c("j", "i"),
                       package = 'rDBEC',
                       add = TRUE)
#' apply_DBEC_filter
#'
#' Main function for applying DBEC background subtraction against gees x cells read count matrix based on
#' gaussian mixture models of biexponential-transformed count distibution.
#'
#' @param x A list of genes/cells mcount data (sparse matrix).
#' @param DBEC_filter A DBEC_filter data frame generated by background_subtraction_Biex function
#' @param nthreads A number of workers
#' @param sample.name A character vector of sample name list
#'
#' @importFrom data.table rbindlist
#' @import doParallel
#' @import parallel
#' @import foreach
#' @importFrom Matrix Matrix colSums
#'
#' @rdname apply_DBEC_filter
#' @return A list of background-subtracted genes x cells count sparse matrix
#' @export
#'

apply_DBEC_filter = function(x,
                             DBEC_filter,
                             nthreads=parallel::detectCores()/2,
                             sample.name) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) == sample.name) != nsamples){stop("x must be named by sample IDs as sample.name vector")}

  for (i in 1:nsamples){
    tmp2 = x[[i]][intersect(rownames(DBEC_filter), rownames(x[[i]])),]
    tmp3 = x[[i]][setdiff(rownames(x[[i]]), rownames(DBEC_filter)),]
    filter = DBEC_filter[intersect(rownames(DBEC_filter), rownames(x[[i]])),i]
    tmp2 = as.matrix(tmp2)

    #apply DBEC filter to read count matrix
    cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    res3 = foreach::foreach (j = c(1:nrow(tmp2)),
                    .final=data.table::rbindlist,
                    .packages=c("data.table"),
                    .inorder=TRUE,
                    .multicombine=TRUE,
                    .maxcombine=nrow(tmp2),
                    .noexport=setdiff(ls(),c("tmp2", "filter"))
    ) %dopar% {
      filtering(tmp2, j, filter)
    }
    parallel::stopCluster(cl)

    res3 = as.matrix(res3)
    res3 = Matrix::Matrix(res3, sparse = TRUE)
    res3 = rbind(res3, tmp3)
    rownames(res3) = c(rownames(tmp2),rownames(tmp3))
    colnames(res3) = colnames(x[[i]])
    tablelist[[i]]=res3
    rm(tmp2)
    rm(tmp3)
    rm(res3)
    invisible(replicate(5, gc()))
  }
  names(tablelist)=sample.name
  return(tablelist)
}


#' apply_DBEC_filter_scTCR
#'
#' Main function for applying DBEC background subtraction against gees x cells read count matrix based on
#' gaussian mixture models of biexponential-transformed count distibution.
#'
#' @param x A list of genes/cells mcount data (sparse matrix).
#' @param DBEC_filter A DBEC_filter data frame generated by background_subtraction_Biex function
#' @param nthreads A number of workers
#' @param sample.name A character vector of sample name list
#'
#' @importFrom dplyr bind_cols
#' @import doParallel
#' @import parallel
#' @import foreach
#' @importFrom Matrix Matrix colSums
#'
#' @rdname apply_DBEC_filter_scTCR
#' @return A list of background-subtracted genes x cells count sparse matrix
#' @export
#'

apply_DBEC_filter_scTCR = function(x,
                             DBEC_filter,
                             nthreads=parallel::detectCores()/2,
                             sample.name) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) == sample.name) != nsamples){stop("x must be named by sample IDs as sample.name vector")}

  for (i in 1:nsamples){
    tmp2 = x[[i]][intersect(rownames(DBEC_filter), rownames(x[[i]])),]
    tmp3 = x[[i]][setdiff(rownames(x[[i]]), rownames(DBEC_filter)),]
    filter = DBEC_filter[intersect(rownames(DBEC_filter), rownames(x[[i]])),i]
    tmp2 = as.matrix(tmp2)

    #apply DBEC filter to read count matrix
    cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    res3 = foreach::foreach (j = c(1:ncol(tmp2)),
                             .final=dplyr::bind_cols,
                             .packages=c("dplyr"),
                             .inorder=TRUE,
                             .multicombine=TRUE,
                             .maxcombine=ncol(tmp2),
                             .noexport=setdiff(ls(),c("tmp2", "filter", "filtering_TCR"))
    ) %dopar% {
      filtering_TCR(tmp2, j, filter)
    }
    parallel::stopCluster(cl)

    res3 = as.matrix(res3)
    tmp3 = as.matrix(tmp3)
    res3 = rbind(res3, tmp3)
    rownames(res3) = c(rownames(tmp2),rownames(tmp3))
    colnames(res3) = colnames(x[[i]])
    res3=res3[,Matrix::colSums(res3, na.rm = TRUE)>0]
    tablelist[[i]]=as.data.frame(res3)
    rm(tmp2)
    rm(tmp3)
    rm(res3)
    invisible(replicate(5, gc()))
  }
  names(tablelist)=sample.name
  return(tablelist)
}

#' filtering
#'
#' Internal function for apply DBEC filter against read count matrix for parallel processing
#'
#' @param x A sparse matrix count data files
#' @param y rownumber of background-subtraction applying gene
#' @param DBEC_filter A DBEC_filter data frame
#'
#' @rdname filtering
#' @return A one-line numeric data frame
#'

filtering = function(x, y, DBEC_filter) {
  hoge = as.numeric(x[y,])
  hoge = replace(hoge,(hoge<=DBEC_filter[y]),0)
  names(hoge)=colnames(x)
  hoge=as.data.frame(hoge)
  hoge=t(hoge)
  hoge=as.data.frame(hoge)
  return(hoge)
}

#' filtering_TCR
#'
#' Internal function for apply DBEC filter against read count matrix for parallel processing
#'
#' @param x A sparse matrix count data files
#' @param y colnumber of background-subtraction applying TCR clone-count data
#' @param DBEC_filter A DBEC_filter data frame
#'
#' @rdname filtering_TCR
#' @return A one-column numeric data frame
#'

filtering_TCR = function(x, y, DBEC_filter) {
  hoge = x[,y]
  hoge[hoge!=max(hoge)] = replace(hoge[hoge!=max(hoge)],(hoge[hoge!=max(hoge)]<=DBEC_filter[hoge!=max(hoge)]),0)
  names(hoge)=rownames(x)
  hoge=as.data.frame(hoge)
  return(hoge)
}

#' filtering_NA
#'
#' Internal function for replace NA to mean threshold from DBEC filter table for parallel processing
#'
#' @param DBEC_filter A data frame of DBEC threshold counts
#' @param y rownumber of background-subtraction applying gene
#' @param DBEC_filter_mean A numeric vector of mean counts of DBEC thresholds.
#' @param ave_hvg A numeric vector of mean counts of lower quantile of hvg mean count
#'
#' @rdname filtering_NA
#' @return A one-line numeric data frame
#'

filtering_NA = function(DBEC_filter, y, DBEC_filter_mean, ave_hvg) {
  hoge = as.numeric(DBEC_filter[y,])
  ave_hvg_temp=ave_hvg[!is.na(hoge)]
  ave_hvg_temp_mean=mean(ave_hvg_temp)
  ave_hvg_temp=ave_hvg / ave_hvg_temp_mean
  hoge = replace(hoge,is.na(hoge), (ave_hvg_temp*DBEC_filter_mean)[is.na(hoge)])
  names(hoge)=colnames(DBEC_filter)
  hoge=as.data.frame(hoge)
  hoge=t(hoge)
  hoge=as.data.frame(hoge)
  return(hoge)
}
