#' tableread_fast_sparse
#'
#' fast read count data table as sparse matrix
#'
#' @param x A list of PASS to the tab-delimitered scRNA-seq count data files
#' @param sep A delimiter of count data table
#' @param header Logical. Whether count data file contains header (Cell IDs) or not
#'
#' @importFrom data.table fread
#' @importFrom Matrix Matrix
#'
#' @rdname tableread_fast_sparse
#' @return A genes x cells count sparse matrix
#' @export
#'

tableread_fast_sparse = function(x, sep="\t", header=TRUE){
  tmp = data.table::fread(x, header=header, sep=sep, quote="")
  tmp = as.data.frame(tmp)
  rownames(tmp) = tmp[,1]
  tmp = tmp[,2:ncol(tmp)]
  tmp = as.matrix(tmp)
  tmp = Matrix::Matrix(tmp, sparse = TRUE)
  return(tmp)
}

#' tableread_fast
#'
#' fast read count data table as dense matrix
#'
#' @param x A list of PASS to the tab-delimitered scRNA-seq count data files
#' @param sep A delimiter of count data table
#' @param header Logical. Whether count data file contains header (Cell IDs) or not
#'
#' @importFrom data.table fread
#'
#' @rdname tableread_fast
#' @return A genes x cells count sparse matrix
#' @export
#'

tableread_fast = function(x, sep="\t", header=TRUE){
  tmp = data.table::fread(x, header=TRUE, sep="\t", quote="")
  tmp = as.data.frame(tmp)
  rownames(tmp) = tmp[,1]
  tmp = tmp[,2:ncol(tmp)]
  return(tmp)
}
