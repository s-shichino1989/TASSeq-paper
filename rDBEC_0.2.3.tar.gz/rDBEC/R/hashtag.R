globalVariables(names = c("i", "j", "k", "l"),
                package = 'rDBEC',
                add = TRUE)
#' hashtag_extract
#'
#' annotate hashtag singlepositive cells from hashtag read count matrix
#' based on gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of each gene is automatically determined by flowTrans package.
#'
#' @param x A list of hashtag/cells count data (format is txt, column=Cell barcode, rownames=hashtags). Must be named as sample.name vector
#' @param sample.name A character vector of sample name list
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak. default=5
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak. default=4.5
#' @param flooring A cutoff value of hashtag count. default=2
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package. default=1
#'
#' @import doParallel
#' @import parallel
#' @import foreach
# @import MASS
#' @importFrom Matrix rowSums
# @import mclust
# @import flowTrans
# @import flowCore
# @import grDevices
# @import graphics
#'
#' @rdname hashtag_extract
#' @return A list of hashtags x cells two-column matrix
#' @export
#'

hashtag_extract = function(x,
                           sample.name,
                           modelnames="E",
                           min.ave=5,
                           min.diff=4.5,
                           flooring=2,
                           uncert.thre=1) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  if(sum(names(x) == sample.name) != nsamples){stop("x must be named by sample IDs as sample.name vector")}
  result=list()

  for (i in 1:nsamples){
    dir.name = sprintf("./hashtag_thresholds_%s", sample.name[i])
    if(file.exists(dir.name)==FALSE){dir.create(dir.name)}

    tmp1 = x[[i]]
    if(length(min.ave)>1){
      minimum_ave=min.ave[i]
    } else {minimum_ave=min.ave}

    #calculate background thresholds
    cl = parallel::makeCluster(nrow(tmp1), type="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    thresholds = foreach (j = 1:nrow(tmp1),
                   .combine='c',
                   .packages=c("mclust","Matrix","MASS", "flowTrans"),
                   .multicombine=TRUE,
                   .maxcombine=nrow(tmp1),
                   .inorder=TRUE,
                   .export=c("background_subtraction_Biex_wrapper"),
                   .noexport=setdiff(ls(),c("tmp1", "dir.name", "background_subtraction_Biex_wrapper",
                                            "minimum_ave", "min.diff", "uncert.thre",
                                            "modelnames", "flooring"))
    ) %dopar% {
      background_subtraction_Biex_wrapper(tmp1,
                                          j,
                                          modelnames=modelnames,
                                          min.ave=minimum_ave,
                                          min.diff=min.diff,
                                          flooring=flooring,
                                          uncert.thre=uncert.thre,
                                          dir.name=dir.name)
    }
    parallel::stopCluster(cl)
    closeAllConnections()
    rm(cl)
    invisible(replicate(5, gc()))

    #binarization of hashtag count
    hashtags = t(tmp1)
    res=NULL
    for (k in c(1:ncol(hashtags))){
      hoge = as.numeric(hashtags[,k])
      hoge = replace(hoge,(hoge <= thresholds[k]),0)
      hoge = replace(hoge,(hoge > thresholds[k]),1)
      names(hoge)=rownames(hashtags)
      res=cbind(res,hoge)
    }

    colnames(res)=rownames(tmp1)
    res1=res[Matrix::rowSums(res)==1,]
    res1=as.data.frame(res1)

    #reshape hashtag-annotation table into two-column format (1st column=CellBC, 2nd column=Tag ID)
    res3=NULL
    for (l in c(1:ncol(hashtags))){
      res2=res1[res1[,l]==1,]
      res2=cbind(res2, Tag=rep(colnames(res1)[l], nrow(res2)))
      res3=rbind(res3, res2)
    }
    res3=res3[,ncol(res3),drop=F]
    res3=cbind(CellBC=rownames(res3),res3)

    result[[i]]=as.data.frame(res3)
  }
  names(result)=sample.name
  return(result)
}

globalVariables(names = c("i"),
                package = 'rDBEC',
                add = TRUE)
#' hashtag_demulti
#'
#' extract hashtag-single positive cells from genes x cells count data sparse matrix
#' and add hahstag IDs to each cell ID.
#'
#' @param x A list of genes x cells count data (format is csv, column=hahstags, rownames=Cell barcode).
#' @param y A list of annotated hashtag x cells two-line data (output of hashtag_extract function).
#' @param sample.name A character vector of sample name list
#'
#' @importFrom Matrix rowSums Matrix
#'
#' @rdname hashtag_demulti
#' @return A named list of hashtag-annotated genes x cells count sparse matrix
#' @export
#'
#'

hashtag_demulti = function(x,
                           y,
                           sample.name) {

  if(class(x)!="list"){stop("x must be a list of read count sparse matrix file")}
  nsamples=length(x)
  if(nsamples == 0){stop("x must be contain at least one read count sparse matrix file")}
  tablelist=list()
  if(sum(names(x) == sample.name) != nsamples || sum(names(y) == sample.name) != nsamples){
    stop("names of expression table and hashtag table are not identical. Sample information must be cheched")
  }

  for (i in c(1:nsamples)){
    hoge = x[[i]]
    hoge1 = y[[i]]
    hoge1 = cbind(hoge1, paste(hoge1[,2],hoge1[,1], sep="_"))

    fuga = hoge[,colnames(hoge) %in% hoge1[,1]]
    fuga = as.matrix(fuga)
    fuga = as.data.frame(fuga)
    fuga = fuga[,order(colnames(fuga))]

    hoge1 = hoge1[order(hoge1[,1]),]
    hoge1 = hoge1[hoge1[,1] %in% colnames(fuga),]
    colnames(fuga) = hoge1[,3]
    fuga = fuga[Matrix::rowSums(fuga)>0,]
    fuga = Matrix::Matrix(as.matrix(fuga), sparse = TRUE)
    tablelist[[i]]=fuga
    gc()
  }
  names(tablelist)=sample.name
  return(tablelist)
}
