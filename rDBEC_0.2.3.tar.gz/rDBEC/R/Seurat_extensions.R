globalVariables(names = c('j'), package = 'rDBEC', add = TRUE)

#' Gene expression markers of identity classes
#'
#' Finds markers (differentially expressed genes) for identity classes by parallel execution
#'
#' @param object Seurat object
#' @param AllcellsIdent identities for DE test. Default is ident slot of Seurat object.
#' @param features.use Genes to test. Default is to use all genes
#' @param logfc.threshold Limit testing to genes which show, on average, at least
#' X-fold difference (log-scale) between the two groups of cells. Default is 0.25
#' Increasing logfc.threshold speeds up the function, but can miss weaker signals.
#' @param test.use Denotes which test to use. Available option is
#' @param min.pct  only test genes that are detected in a minimum fraction of
#' min.pct cells in either of the two populations. Meant to speed up the function
#' by not testing genes that are very infrequently expressed. Default is 0.1
#' @param min.diff.pct  only test genes that show a minimum difference in the
#' fraction of detection between the two groups. Set to -Inf by default
#' @param only.pos Only return positive markers (FALSE by default)
#' @param min.cells.gene Minimum number of cells expressing the gene in at least one
#' of the two groups, currently only used for poisson and negative binomial tests
#' @param min.cells.group Minimum number of cells in one of the groups
#' @param pseudocount.use Pseudocount to add to averaged expression values when
#' calculating logFC. 1 by default.
#' @param adj.p.val.threshold Maximum threshold bonferroni-adjusted p-value of each gene. 0.05 by default.
#' @param nthreads Number of workers for parallel processing. detectCores()/2 by default.
#' @return Matrix containing a ranked list of putative markers, and associated
#' statistics (p-values, ROC score, etc.)
#' @details p-value adjustment is performed using bonferroni correction based on
#' the total number of genes in the dataset. Other correction methods are not
#' recommended, as Seurat pre-filters genes using the arguments above, reducing
#' the number of tests performed. Lastly, as Aaron Lun has pointed out, p-values
#' should be interpreted cautiously, as the genes used for clustering are the
#' same genes tested for differential expression.
#'
#' @importFrom Matrix rowSums
#' @importFrom Seurat GetAssayData
#' @import doParallel
#' @import parallel
#' @import foreach
#' @importFrom dplyr bind_rows
#' @rdname FindMarkers_parallel_lite
#' @export

FindMarkers_parallel_lite = function(object,
                                     AllcellsIdent=NULL,
                                     test.use="wilcox",
                                     only.pos=TRUE,
                                     logfc.threshold = 0.25,
                                     min.pct=0.25,
                                     min.diff.pct = -Inf,
                                     features.use = NULL,
                                     min.cells.gene = 3,
                                     min.cells.group = 3,
                                     pseudocount.use = 1,
                                     nthreads = detectCores()/2,
                                     adj.p.val.threshold=0.05
) {
  if (object@version == "2.3.4"){
    data.use=GetAssayData(object)
    if (is.null(AllcellsIdent)){
      AllcellsIdent = object@ident
    }
    tmp = levels(AllcellsIdent)
  } else if (object@version >= "3.0"){
    data.use=GetAssayData(object, assay = "RNA", slot = "data")
    if (is.null(AllcellsIdent)){
      AllcellsIdent = object@active.ident
    }
    tmp = levels(AllcellsIdent)
  }
  if(is.null(features.use)){
    for (i in tmp){
      cells.1 = names(AllcellsIdent[AllcellsIdent == i])
      pct.1 <- round(
        x = Matrix::rowSums(x = data.use[, cells.1, drop = FALSE] > 0) /
          length(x = cells.1),
        digits = 3
      )
      features <- names(x = which(x = pct.1 > min.pct))
      features.use = unique(c(features, features.use))
    }
  }
  data.use=data.use[features.use,]
  cl = parallel::makeCluster(nthreads, type ="PSOCK", useXDR=FALSE)
  doParallel::registerDoParallel(cl)
  DE.markers = foreach (j = tmp, .combine=dplyr::bind_rows, .inorder=TRUE,
                        .packages=c("dplyr"), .multicombine=TRUE,
                        .export = c("WilcoxDETest", "FindMarkers.parallel.wilcox"),
                        .noexport=setdiff(ls(),c("data.use","AllcellsIdent",
                                                 "min.pct","only.pos", "features.use","adj.p.val.threshold"
                        ))) %dopar% {
                          FindMarkers.parallel.wilcox(data.use = data.use,
                                                      AllcellsIdent = AllcellsIdent,
                                                      ident.1 = j,
                                                      ident.2 = NULL,
                                                      genes.use = features.use,
                                                      logfc.threshold = 0.25,
                                                      test.use="wilcox",
                                                      min.diff.pct = -Inf,
                                                      only.pos = only.pos,
                                                      min.cells.gene = 3,
                                                      min.cells.group = 3,
                                                      pseudocount.use = 1
                          )
                        }
  parallel::stopCluster(cl)
  gc()
  DE.markers = as.data.frame(DE.markers)
  if(nrow(DE.markers)>0){
  DE.markers = DE.markers[DE.markers$p_val_adj<adj.p.val.threshold,]
  }
  return(DE.markers)
}

globalVariables(names = 'avg_logFC', package = 'rDBEC', add = TRUE)

#' Gene expression markers of identity classes (internal)
#'
#' Wrapper of Finds markers (differentially expressed genes) by wilcox.rank.sum test
#' for identity classes by parallel execution
#'
#' @param data.use gene expression matrix for DE test
#' @param AllcellsIdent identities for DE test. Default is ident slot of Seurat object.
#' @param ident.1 Identity class to define markers for
#' @param ident.2 A second identity class for comparison. If NULL (default) -
#' use all other cells for comparison.
#' @param genes.use Genes to test. Default is to use all genes
#' @param logfc.threshold Limit testing to genes which show, on average, at least
#' X-fold difference (log-scale) between the two groups of cells. Default is 0.25
#' Increasing logfc.threshold speeds up the function, but can miss weaker signals.
#' @param test.use Denotes which test to use. Available option is:
#' @param min.pct  only test genes that are detected in a minimum fraction of
#' min.pct cells in either of the two populations. Meant to speed up the function
#' by not testing genes that are very infrequently expressed. Default is 0.1
#' @param min.diff.pct  only test genes that show a minimum difference in the
#' fraction of detection between the two groups. Set to -Inf by default
#' @param only.pos Only return positive markers (FALSE by default)
#' @param min.cells.gene Minimum number of cells expressing the gene in at least one
#' of the two groups, currently only used for poisson and negative binomial tests
#' @param random.seed Random seed for downsampling
#' @param min.cells.group Minimum number of cells in one of the groups
#' @param pseudocount.use Pseudocount to add to averaged expression values when
#' calculating logFC. 1 by default.
#' @return Matrix containing a ranked list of putative markers, and associated
#' statistics (p-values, ROC score, etc.)
#' @details p-value adjustment is performed using bonferroni correction based on
#' the total number of genes in the dataset. Other correction methods are not
#' recommended, as Seurat pre-filters genes using the arguments above, reducing
#' the number of tests performed. Lastly, as Aaron Lun has pointed out, p-values
#' should be interpreted cautiously, as the genes used for clustering are the
#' same genes tested for differential expression.
#' @importFrom Matrix rowSums
#' @importFrom stats p.adjust
#'
#' @export
#'
#' @rdname FindMarkers.parallel.wilcox
#'

FindMarkers.parallel.wilcox = function(
  data.use,
  AllcellsIdent,
  ident.1 = NULL,
  ident.2 = NULL,
  genes.use = NULL,
  logfc.threshold = 0.25,
  test.use = 'wilcox',
  min.pct = 0.25,
  min.diff.pct = -Inf,
  only.pos = FALSE,
  random.seed = 1,
  min.cells.gene = 3,
  min.cells.group = 3,
  pseudocount.use = 1
) {
  if (is.null(genes.use)) {
    features = rownames(data.use)
  } else {
    features=genes.use
  }

  cells.1 = names(AllcellsIdent[AllcellsIdent %in% ident.1])
  if (is.null(ident.2)) {
    cells.2 = setdiff(names(AllcellsIdent), cells.1)
  } else {
    cells.2 = names(AllcellsIdent[AllcellsIdent %in% ident.2])
  }
  cells.2 = setdiff(x = cells.2, y = cells.1)

  thresh.min <- 0
  pct.1 <- round(
    x = Matrix::rowSums(x = data.use[features, cells.1, drop = FALSE] > thresh.min) /
      length(x = cells.1),
    digits = 3
  )
  pct.2 <- round(
    x = Matrix::rowSums(x = data.use[features, cells.2, drop = FALSE] > thresh.min) /
      length(x = cells.2),
    digits = 3
  )
  data.alpha <- cbind(pct.1, pct.2)
  colnames(x = data.alpha) <- c("pct.1", "pct.2")
  alpha.min <- apply(X = data.alpha, MARGIN = 1, FUN = max)
  names(x = alpha.min) <- rownames(x = data.alpha)
  features <- names(x = which(x = pct.1 > min.pct))
  if (length(x = features) == 0) {
    print("No features pass min.pct threshold")
  } else {
    alpha.diff <- alpha.min - apply(X = data.alpha, MARGIN = 1, FUN = min)
    features <- names(
      x = which(x = pct.1 > min.pct & alpha.diff > min.diff.pct)
    )
    if (length(x = features) == 0) {
      print("No features pass min.diff.pct threshold")
    } else {

      data.1 <- apply(
        X = data.use[features, cells.1, drop = FALSE],
        MARGIN = 1,
        FUN = function(x)(log(x = mean(x = expm1(x = x)) + pseudocount.use)))

      data.2 <- apply(
        X = data.use[features, cells.2, drop = FALSE],
        MARGIN = 1,
        FUN = function(x)(log(x = mean(x = expm1(x = x)) + pseudocount.use)))
      total.diff <- (data.1 - data.2)
      features.diff <- if (only.pos) {
        names(x = which(x = total.diff > logfc.threshold))
      }
      features <- intersect(x = features, y = features.diff)
      if (length(x = features) == 0) {
        print("No features pass logfc.threshold threshold")
      }

    }}
  if(test.use=="wilcox" && length(x = features) != 0){
    de.results <- WilcoxDETest.modified(
      data.use = data.use[features, c(cells.1, cells.2), drop = FALSE],
      cells.1 = cells.1,
      cells.2 = cells.2)
    if (exists("de.results") == TRUE) {
      diff.col = "avg_logFC"
      de.results[, diff.col] <- total.diff[rownames(x = de.results)]

      exp.1.col = "within_avg_exp"
      de.results[, exp.1.col] <- data.1[rownames(x = de.results)]
      exp.2.col = "without_avg_exp"
      de.results[, exp.2.col] <- data.2[rownames(x = de.results)]
      nCells = rep(length(cells.1), nrow(de.results))
      names(nCells)=rownames(de.results)
      de.results[, "cluster_CellNumber"] <- nCells[rownames(x = de.results)]
      de.results <- cbind(de.results, data.alpha[rownames(x = de.results), , drop = FALSE])
      if (only.pos) {
        de.results <- de.results[de.results[, diff.col] > 0, , drop = FALSE]
      }
      de.results <- de.results[order(de.results$p_val, -de.results[, diff.col]), ]
      de.results$p_val_adj = stats::p.adjust(
        p = de.results$p_val,
        method = "bonferroni",
        n = nrow(x = data.use)
      )
      de.results$cluster = rep(ident.1, nrow(de.results))
      de.results$gene =  rownames(de.results)
      #de.results = de.results[de.results$p_val_adj<adj.p.val.threshold,, drop = FALSE]
    } else {de.resutls=NULL}
  } else if (test.use !="wilcox"){
    stop("Invalid test method")
  } else {de.resutls=NULL}
  gc()
  if (exists("de.results") == TRUE && is.null(de.results) == FALSE) {
    return(de.results)} else {return(NULL)}
}

#' Differential expression using Wilcoxon Rank Sum (modified for parallel execution)
#'
#' Identifies differentially expressed genes between two groups of cells using
#' a Wilcoxon Rank Sum test
#' @param data.use count matrix for DE tests
#' @param cells.1 Group 1 cells
#' @param cells.2 Group 2 cells
#'
#' @return Returns a p-value ranked matrix of putative differentially expressed
#' genes.
#'
#' @importFrom stats wilcox.test
#'
#' @export
#'
#' @rdname WilcoxDETest.modified
#'

WilcoxDETest.modified <- function(
  data.use,
  cells.1,
  cells.2
) {
  group.info <- data.frame(row.names = c(cells.1, cells.2))
  group.info[cells.1, "group"] <- "Group1"
  group.info[cells.2, "group"] <- "Group2"
  group.info[, "group"] <- factor(x = group.info[, "group"])
  data.use <- data.use[, rownames(x = group.info), drop = FALSE]
  p_val <- sapply(
    X = 1:nrow(x = data.use),
    FUN = function(x) {
      return(stats::wilcox.test(data.use[x, ] ~ group.info[, "group"])$p.value)
    }
  )
  return(data.frame(p_val, row.names = rownames(x = data.use)))
}

globalVariables(names = c('cell', 'gene'), package = 'rDBEC', add = TRUE)
#' Gene expression heatmap
#'
#' Draws a heatmap of single cell gene expression using ggplot2.
#'
#' @param object Seurat object
#' @param data.use Option to pass in data to use in the heatmap. Default will pick from either
#' object@@data or object@@scale.data depending on use.scaled parameter. Should have cells as columns
#' and genes as rows.
#' @param use.scaled Whether to use the data or scaled data if data.use is NULL
#' @param cells.use Cells to include in the heatmap (default is all cells)
#' @param genes.use Genes to include in the heatmap (ordered)
#' @param genes.ident default NULL
#' @param disp.min Minimum display value (all values below are clipped)
#' @param disp.max Maximum display value (all values above are clipped)
#' @param group.by Groups cells by this variable. Default is object@@ident
#' @param group.order Order of groups from left to right in heatmap.
#' @param draw.line Draw vertical lines delineating different groups
#' @param col.low Color for lowest expression value
#' @param col.mid Color for mid expression value
#' @param col.high Color for highest expression value
#' @param slim.col.label display only the identity class name once for each group
#' @param remove.key Removes the color key from the plot.
#' @param rotate.key Rotate color scale horizantally
#' @param title Title for plot
#' @param cex.col Controls size of column labels (cells)
#' @param cex.row Controls size of row labels (genes)
#' @param group.label.loc Place group labels on bottom or top of plot.
#' @param group.label.rot.x Whether to rotate the column group label.
#' @param group.label.rot.y Whether to rotate the row group label.
#' @param group.cex Size of group label text
#' @param group.spacing Controls amount of space between columns.
#' @param assay.type to plot heatmap for (default is RNA)
#' @param do.plot Whether to display the plot.
#'
#' @return Returns a ggplot2 plot object
#'
#' @importFrom dplyr %>%
#' @importFrom reshape2 melt
#' @import ggplot2
#' @importFrom Seurat GetAssayData FetchData MinMax PurpleAndYellow
#'
#' @export
#'
#' @rdname DoHeatmap2
#'

DoHeatmap2 <- function(
  object,
  data.use = NULL,
  use.scaled = TRUE,
  cells.use = NULL,
  genes.use = NULL,
  genes.ident = NULL,
  disp.min = -2.5,
  disp.max = 2.5,
  group.by = "ident",
  group.order = NULL,
  draw.line = TRUE,
  col.low = "#FF00FF",
  col.mid = "#000000",
  col.high = "#FFFF00",
  slim.col.label = FALSE,
  remove.key = FALSE,
  rotate.key = FALSE,
  title = NULL,
  cex.col = 10,
  cex.row = 10,
  group.label.loc = "bottom",
  group.label.rot.x = FALSE,
  group.label.rot.y = TRUE,
  group.cex = 15,
  group.spacing = 0.15,
  assay.type = "RNA",
  do.plot = TRUE
) {
  if (is.null(x = data.use)) {
    if (use.scaled) {
      data.use <- Seurat::GetAssayData(object,assay.type = assay.type,slot = "scale.data")
    } else {
      data.use <- Seurat::GetAssayData(object,assay.type = assay.type,slot = "data")
    }
  }
  # note: data.use should have cells as column names, genes as row names
  cells.use <- SetIfNull(x = cells.use, default = object@cell.names)
  cells.use <- intersect(x = cells.use, y = colnames(x = data.use))
  if (length(x = cells.use) == 0) {
    stop("No cells given to cells.use present in object")
  }
  genes.use <- SetIfNull(x = genes.use, default = rownames(x = data.use))
  genes.use <- intersect(x = genes.use, y = rownames(x = data.use))
  if (length(x = genes.use) == 0) {
    stop("No genes given to genes.use present in object")
  }
  if (is.null(x = group.by) || group.by == "ident") {
    cells.ident <- object@ident[cells.use]
    genes.ident <- factor(x = genes.ident, levels=unique(genes.ident))
    names(x = genes.ident) <- genes.use
  } else {
    cells.ident <- factor(x = Seurat::FetchData(
      object = object,
      cells.use = cells.use,
      vars.all = "ident"
    )[, 1])
    names(x = cells.ident) <- cells.use
    cells.ident <- factor(
      x = cells.ident,
      labels = intersect(x = levels(x = cells.ident), y = cells.ident)
    )

    genes.ident <- factor(x = genes.ident, levels=unique(genes.ident))
    names(x = genes.ident) <- genes.use
    genes.ident <- factor(
      x = genes.ident,
      labels = intersect(x = levels(x = genes.ident), y = genes.ident)
    )
  }

  data.use <- data.use[genes.use, cells.use, drop = FALSE]
  if ((!use.scaled)) {
    data.use = as.matrix(x = data.use)
    if (disp.max==2.5) disp.max = 10;
  }
  data.use <- Seurat::MinMax(data = data.use, min = disp.min, max = disp.max)
  data.use <- as.data.frame(x = t(x = data.use))
  data.use$cell <- rownames(x = data.use)
  colnames(x = data.use) <- make.unique(names = colnames(x = data.use))
  data.use %>% reshape2::melt(id.vars = "cell") -> data.use
  #data.use %>% tidyr::gather(key = "cell") -> data.use
  data.use = as.data.frame(data.use)
  names(x = data.use)[names(x = data.use) == 'variable'] <- 'gene'
  names(x = data.use)[names(x = data.use) == 'value'] <- 'expression'
  data.use$ident.cell <- cells.ident[data.use$cell]
  data.use$ident.genes <- genes.ident[data.use$gene]
  if(!is.null(group.order)) {
    if(length(group.order) == length(levels(data.use$ident.cell)) && all(group.order %in% levels(data.use$ident.cell))) {
      data.use$ident.cell <- factor(data.use$ident.cell, levels = group.order)
    }
    else {
      stop("Invalid group.order")
    }
  }
  breaks <- seq(
    from = min(data.use$expression),
    to = max(data.use$expression),
    length = length(x = Seurat::PurpleAndYellow()) + 1
  )
  data.use$gene <- with(
    data = data.use,
    expr = factor(x = gene, levels = rev(x = unique(x = data.use$gene)))
  )
  data.use$cell <- with(
    data = data.use,
    expr = factor(x = cell, levels = cells.use)
  )
  # might be a solution if we want discrete interval units, makes the legend clunky though
  #data.use$expression <- cut(data.use$expression, breaks = breaks, include.lowest = T)
  #heatmap <- ggplot(data.use, aes(x = cell, y = gene, fill = expression)) + geom_tile() +
  #                  scale_fill_manual(values = PurpleAndYellow(), name= "Expression") +
  #                  scale_y_discrete(position = "right", labels = rev(genes.use)) +
  #                  theme(axis.line=element_blank(), axis.title.y=element_blank(),
  #                        axis.ticks.y = element_blank())
  if (rotate.key) {
    key.direction <- "horizontal"
    key.title.pos <- "top"
  } else {
    key.direction <- "vertical"
    key.title.pos <- "left"
  }
  heatmap <- ggplot(
    data = data.use,
    mapping = aes(x = cell, y = gene, fill = expression)
  ) +
    geom_tile() +
    scale_fill_gradient2(
      low = col.low,
      mid = col.mid,
      high = col.high,
      name= "Expression",
      guide = guide_colorbar(
        direction = key.direction,
        title.position = key.title.pos
      )
    ) +
    theme(
      axis.line = element_blank(),
      axis.title.y = element_blank(),
      axis.ticks.y = element_blank(),
      strip.text.x = element_text(size = group.cex),
      axis.text.y = element_text(size = cex.row),
      axis.text.x = element_text(size = cex.col),
      axis.title.x = element_blank()
    )
  if (slim.col.label) {
    heatmap <- heatmap +
      theme(
        axis.title.x = element_blank(),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks.y = element_blank()
      )
  } else {
    heatmap <- heatmap + theme(axis.text.x = element_text(angle = 90))
  }
  if (! is.null(x = group.by)) {
    if (group.label.loc == "top") {
      switch <- NULL
      # heatmap <- heatmap +
      #   facet_grid(
      #     facets = ~ident,
      #     drop = TRUE,
      #     space = "free",
      #     scales = "free"
      #   ) +
      #   scale_x_discrete(expand = c(0, 0), drop = TRUE)
    } else {
      switch <- 'x'
      # heatmap <- heatmap +
      #   facet_grid(
      #     facets = ~ident,
      #     drop = TRUE,
      #     space = "free",
      #     scales = "free",
      #     switch = "x"
      #   ) +
      #   scale_x_discrete(expand = c(0, 0), drop = TRUE)
    }
    heatmap <- heatmap +
      facet_grid(
        ident.genes ~ ident.cell,
        drop = TRUE,
        space = "free",
        scales = "free",
        switch = switch
      ) +
      scale_x_discrete(expand = c(0, 0), drop = TRUE) +
      scale_y_discrete(position = "right", expand = c(0, 0), drop = TRUE)
    if (draw.line) {
      panel.spacing <- unit(x = group.spacing, units = 'lines')
      # heatmap <- heatmap + theme(strip.background = element_blank(), panel.spacing = unit(group.spacing, "lines"))
    } else {
      panel.spacing <- unit(x = 0, units = 'lines')
      #
    }
    heatmap <- heatmap +
      theme(strip.background = element_blank(), panel.spacing = panel.spacing)
    if (group.label.rot.x) {
      heatmap <- heatmap + theme(strip.text.x = element_text(angle = 90))
    }
    if (group.label.rot.y) {
      heatmap <- heatmap + theme(strip.text.y = element_text(angle = 0))
    }
  }
  if (remove.key) {
    heatmap <- heatmap + theme(legend.position = "none")
  }
  if (! is.null(x = title)) {
    heatmap <- heatmap + labs(title = title)
  }
  if (do.plot) {
    heatmap
  }
  return(heatmap)
}

#' Set a default value if an object is null
#'
#' Internal function for DoHeatmap2 function.
#'
#' @param x An object to set if it's null
#' @param default The value to provide if x is null
#'
#' @return default if x is null, else x
#
SetIfNull <- function(x, default) {
  if(is.null(x = x)){
    return(default)
  } else {
    return(x)
  }
}

#' @title PushData
#'
#' @description Helper function to assist entering dimensional reduction data from Python
#' reduction methods
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param python_df Dataframe returned by a Python function
#' @param reduction_use Name to use for the reduction (i. e. tsne, umap,
#' etc...)
#' @param reduction_save Name to use for the reduction (i. e. tsne, umap,
#' etc...)
#' @param dims_use Number of reduced dimensions to use for further projection.
#'
#' @importFrom glue glue
#' @importFrom magrittr %<>%
#'
#' @rdname PushData
#' @return Seurat object
#' @export
#'
PushData <- function(object,
                     python_df,
                     reduction_use,
                     reduction_save,
                     dims_use) {
  python_df %<>% as.matrix()
  if (object@version == "2.3.4"){
    data.use <- Seurat::GetDimReduction(
      object = object,
      reduction.type = reduction_use,
      slot = "cell.embeddings"
    )[, dims_use]
    colnames(x = python_df) <- paste0(reduction_save, 1:ncol(x = python_df))
    rownames(x = python_df) <- rownames(x = data.use)
    object <- Seurat::SetDimReduction(
      object = object,
      reduction.type = reduction_save,
      slot = "cell.embeddings",
      new.data = python_df
    )
    object <- Seurat::SetDimReduction(
      object = object,
      reduction.type = reduction_save,
      slot = "key",
      new.data = as.character(glue::glue("{reduction_save}_"))
    )
  } else if  (object@version >= "3.0"){
    rownames(python_df) = colnames(object)
    reduction_data = Seurat::CreateDimReducObject(
      embeddings = python_df,
      assay = Seurat::DefaultAssay(object = object[[reduction_use]]),
      key = as.character(glue::glue("{reduction_save}_"))
    )
    object[[reduction_save]] = reduction_data
  }
  return(object)
}

utils::globalVariables(names = c("euclidean", "random", "umap", "barnes_hut", "exact", "fft",
                                 "spectral", "categorical"),
                       package = 'rDBEC',
                       add = TRUE)
#' @title ReductionBridge
#'
#' @description Generalized helper function that pulls the data from an object, passes
#' the dataframe to a Python function, and places the resulting dataframe in the
#' appropriate slot
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param reduction_use Prior dimensional reduction to use for calculations
#' (i.e. pca, ica, cca, etc...)
#' @param reduction_save Name to use for the reduction (i. e. tsne, umap,
#' etc...)
#' @param function_use Dimensional reduction function to call.
#' @param dims_use Dimensions of `reduction_use` to pass to `function_use`
#' @param n_jobs number of workers
#' @param n.components number of reduecte dimensions
#' @param perplexity perplexity value of tSNE dim.reduction. default=40.
#' @param seed random seed for initialization of dimentional reduction
#' @param max_iter maximum iteration for FItSNE embeddings. default=1000
#' @param df degrees of freedom for FItSNE embeddings. default=1
#'
#' @importFrom glue glue
#' @importFrom reticulate import py_module_available py_set_seed
#' @importFrom parallel detectCores
#'
#' @rdname ReductionBridge
#' @return Seurat object
#' @export
ReductionBridge <- function(object,
                            reduction_use = reduction_use,
                            reduction_save = reduction_save,
                            function_use = function_use,
                            dims_use = NULL,
                            n_jobs = n_jobs,
                            n.components = as.integer(2),
                            perplexity = 40,
                            seed=as.integer(42),
                            max_iter=as.integer(1000),
                            df=1) {
  if (object@version == "2.3.4"){
    if (is.element(reduction_use, names(object@dr))) {
      cell_embeddings <- object@dr$pca@cell.embeddings
    } else {
      message(glue::glue("{reduction_use} has not yet been performed"))
      stop()
    }
  } else if (object@version >= "3.0"){
    if (is.element(reduction_use, names(object@reductions))) {
      cell_embeddings = Seurat::Embeddings(object@reductions$pca)
    } else {
      message(glue::glue("{reduction_use} has not yet been performed"))
      stop()
    }

  }
  if (max(dims_use) > ncol(cell_embeddings)) {
    stop(glue::glue("You have selected dimensions that are outside the bounds of {reduction_use}"))
  } else if (function_use == "optSNE"){
    if (!reticulate::py_module_available("MulticoreTSNE")){
      stop("The Multicore-opt-SNE module is unavailable.  Please activate the appropriate environment or install the module.")
    }
    py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
    optsne_module <- reticulate::import(module = "MulticoreTSNE", delay_load = TRUE)
    py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
    optsne <- optsne_module$MulticoreTSNE(n_components = n.components,
                                          perplexity = as.numeric(perplexity),
                                          early_exaggeration = as.numeric(12.0),
                                          learning_rate = as.numeric(round(nrow(cell_embeddings)/12,0)),
                                          n_iter = as.integer(1000),
                                          n_iter_without_progress = as.integer(300),
                                          min_grad_norm = as.numeric(1e-07),
                                          metric = "euclidean",
                                          init = "random",
                                          verbose = as.integer(25),
                                          random_state = seed,
                                          method = "barnes_hut",
                                          angle = as.numeric(0.5),
                                          #auto_iter = TRUE,
                                          #auto_iter_end = as.integer(5000),
                                          n_jobs = as.integer(n_jobs))
    cell_embeddings=cell_embeddings[,dims_use]
    optsne_df <- optsne$fit_transform(cell_embeddings)
    object <- PushData(
      object = object,
      python_df = optsne_df,
      reduction_use = reduction_use,
      reduction_save = reduction_save,
      dims_use = dims_use)
  } else if (function_use == "openTSNE"){
    if (!reticulate::py_module_available("openTSNE")){
      stop("The openTSNE module is unavailable.
           Please activate the appropriate environment or install the module.")
    }
    py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
    openTSNE.module <- reticulate::import(module = "openTSNE", delay_load = TRUE)
    py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
    tsne <- openTSNE.module$TSNE(n_components = n.components,
                                 perplexity = as.numeric(perplexity),
                                 learning_rate = as.numeric(round(nrow(cell_embeddings)/12,0)),
                                 early_exaggeration_iter = as.integer(250),
                                 early_exaggeration = as.numeric(12),
                                 n_iter = as.integer(750),
                                 exaggeration = NULL,
                                 theta = as.numeric(0.5),
                                 n_interpolation_points = as.integer(3),
                                 min_num_intervals = as.integer(10),
                                 ints_in_interval = as.numeric(2),
                                 initialization = as.character("pca"),
                                 metric = as.character("euclidean"),
                                 metric_params = NULL,
                                 initial_momentum = as.numeric(0.5),
                                 final_momentum = as.numeric(0.8),
                                 n_jobs = as.integer(n_jobs),
                                 neighbors = as.character("exact"),
                                 negative_gradient_method = as.character("fft"),
                                 callbacks = NULL,
                                 callbacks_every_iters = as.integer(50),
                                 random_state = seed)
    cell_embeddings=cell_embeddings[,dims_use]
    opentsne_df <- tsne$fit(X = cell_embeddings)
    rownames(opentsne_df) <- rownames(cell_embeddings)
    colnames(opentsne_df) <- paste(rep("openTSNE", ncol(opentsne_df)), c(1:ncol(opentsne_df)), sep="_")
    object <- PushData(
      object = object,
      python_df = opentsne_df,
      reduction_use = reduction_use,
      reduction_save = reduction_save,
      dims_use = dims_use)
    } else if (function_use == "UMAP"){
      if (!reticulate::py_module_available("umap")){
        stop("The umap module is unavailable.  Please activate the appropriate environment or install the module.")
      }
      py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
      umap.module <- reticulate::import(module = "umap", delay_load = TRUE)
      py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
      umap.embed <- umap.module$UMAP(n_neighbors = as.integer(15),
                                     min_dist = as.numeric(0.1),
                                     n_components = n.components,
                                     metric = "euclidean",
                                     init = "spectral",
                                     spread = as.numeric(1.0),
                                     random_state = NULL,
                                     angular_rp_forest = FALSE,
                                     set_op_mix_ratio = as.numeric(1.0),
                                     n_epochs = NULL,
                                     learning_rate = as.numeric(1.0),
                                     local_connectivity = as.integer(1),
                                     repulsion_strength = as.numeric(1.0),
                                     negative_sample_rate = as.integer(5),
                                     transform_queue_size = as.numeric(4.0),
                                     a = as.numeric(NULL),
                                     b = as.numeric(NULL),
                                     metric_kwds = NULL,
                                     target_n_neighbors = as.integer(-1),
                                     target_metric = "categorical",
                                     target_metric_kwds = NULL,
                                     target_weight = as.numeric(0.5),
                                     transform_seed = seed,
                                     verbose = TRUE
      )
      umap.df <- umap.embed$fit_transform(cell_embeddings)
      object <- PushData(
        object = object,
        python_df =  umap.df,
        reduction_use = reduction_use,
        reduction_save = reduction_save,
        dims_use = dims_use)
    }  else if (function_use == "FItSNE"){
      if (!reticulate::py_module_available("fitsne")){
        stop("The fitsne module is unavailable.  Please activate the appropriate environment or install the module.")
      }
      fitsne.module <- reticulate::import(module = "fitsne", delay_load = TRUE)
      cell_embeddings=cell_embeddings[,dims_use]
      py_array <- reticulate::np_array(data = cell_embeddings, order = "C")
      py_set_seed(as.integer(seed), disable_hash_randomization = TRUE)
      fitsne.embed <- fitsne.module$FItSNE(X = py_array,
                                            no_dims=as.integer(2),
                                            #theta=0.5,
                                            perplexity=as.integer(perplexity),
                                            max_iter=as.integer(max_iter),
                                            fft_not_bh=TRUE,
                                            ann_not_vptree=TRUE,
                                            #stop_early_exag_iter=as.integer(250),
                                            #K=as.integer(-1),
                                            #sigma=-30,
                                            #mom_switch_iter=as.integer(250),
                                            #momentum=0.5,
                                            #final_momentum=0.8,
                                            learning_rate=as.integer(round(nrow(cell_embeddings)/12,0)),
                                            #early_exag_coeff=as.integer(12),
                                            no_momentum_during_exag=FALSE,
                                           #n_trees=as.integer(50),
                                           #search_k=as.integer(-1),
                                           #start_late_exag_iter=as.integer(-1),
                                           #late_exag_coeff=-1,
                                           #nterms=as.integer(3),
                                           #intervals_per_integer=as.integer(1),
                                           #min_num_intervals=as.integer(50),
                                            rand_seed=as.integer(seed),
                                            initialization=NULL,
                                            df=df,
                                            nthreads=as.integer(n_jobs)
                                           )
      object <- PushData(
        object = object,
        python_df =  fitsne.embed,
        reduction_use = reduction_use,
        reduction_save = reduction_save,
        dims_use = dims_use)
    }
  return(object)
}


#' @title DoOptSNE
#'
#' @description Perform tSNE projection on a Seurat object using the
#' Multicore-opt-SNE function
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param reduction_use Prior dimensional reduction to use for calculations
#' (i.e. pca, ica, cca, etc...). Default: pca
#' @param reduction_save Name to use for the reduction. Default: optSNE
#' @param dims_use Dimensions from `reduction_use` to pass
#' @param n_jobs number of workers
#' @param perplexity perplexity parameter of tSNE.
#' @param n_components number of reduced dimentions
#' @param random.seed random seed for initialization of dimentional reduction
#'
#' @importFrom parallel detectCores
#'
#' @rdname DoOptSNE
#' @export
#'
DoOptSNE <- function(object,
                     reduction_use = "pca",
                     reduction_save = "optSNE",
                     dims_use = NULL,
                     n_jobs=parallel::detectCores(),
                     perplexity=40.0,
                     n_components=as.integer(2),
                     random.seed=as.integer(42)) {
  object <- ReductionBridge(object,
                            reduction_use = reduction_use,
                            reduction_save = reduction_save,
                            function_use = reduction_save,
                            dims_use = dims_use,
                            perplexity = perplexity,
                            n_jobs=n_jobs,
                            n.components=n_components,
                            seed=random.seed)
  SetcalcParams <- function(object, calculation, time = TRUE, ...) {
    object@calc.params[calculation] <- list(...)
    object@calc.params[[calculation]]$object <- NULL
    object@calc.params[[calculation]]$object2 <- NULL
    if(time) {
      object@calc.params[[calculation]]$time <- Sys.time()
    }
    return(object)
  }
  parameters.to.store <- as.list(environment(), all = TRUE)[names(formals("DoOptSNE"))]
  object <- SetcalcParams(object = object, calculation = "DoOptSNE", ... = parameters.to.store)
  return(object)
}


#' @title DoOpenTSNE
#'
#' @description Perform tSNE projection on a Seurat object using the openTSNE
#' library, with FIt-SNE selected by default
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param reduction_use Prior dimensional reduction to use for calculations
#' (i.e. pca, ica, cca, etc...). Default: pca
#' @param reduction_save Name to use for the reduction. Default: openTSNE
#' @param dims_use Dimensions from `reduction_use` to pass
#' @param n_jobs number of workers
#' @param perplexity perplexity parameter of tSNE.
#' @param n_components number of reduced dimentions
#' @param random.seed random seed for initialization of dimentional reduction
#'
#' @importFrom parallel detectCores
#'
#' @rdname DoOpenTSNE
#' @export
#'
DoOpenTSNE <- function(object,
                       reduction_use = "pca",
                       reduction_save = "openTSNE",
                       dims_use = NULL,
                       n_jobs=parallel::detectCores()/2,
                       perplexity=40.0,
                       n_components=as.integer(2),
                       random.seed=as.integer(42)) {
  object <- ReductionBridge(object,
                            reduction_use = reduction_use,
                            reduction_save = reduction_save,
                            function_use = reduction_save,
                            dims_use = dims_use,
                            perplexity = perplexity,
                            n_jobs=n_jobs,
                            n.components=n_components,
                            seed=random.seed)
  SetcalcParams <- function(object, calculation, time = TRUE, ...) {
    object@calc.params[calculation] <- list(...)
    object@calc.params[[calculation]]$object <- NULL
    object@calc.params[[calculation]]$object2 <- NULL
    if(time) {
      object@calc.params[[calculation]]$time <- Sys.time()
    }
    return(object)
  }
  parameters.to.store <- as.list(environment(), all = TRUE)[names(formals("DoOpenSNE"))]
  object <- Seurat::SetcalcParams(object = object, calculation = "DoOpenSNE", ... = parameters.to.store)
  return(object)
}

#' @title DoUMAP
#'
#' @description Perform UMAP dimentional reduction
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param reduction_use Prior dimensional reduction to use for calculations
#' (i.e. pca, ica, cca, etc...). Default: pca
#' @param reduction_save Name to use for the reduction (i. e. tsne, umap,
#' etc...). Default: UMAP
#' @param dims_use Dimensions from `reduction_use` to pass to PHATE
#' @param n_jobs number of workers
#' @param n_components number of reduced dimentions
#' @param random.seed random seed for initialization of dimentional reduction
#'
#'
#' @rdname DoUMAP
#' @export
#'
DoUMAP <- function(object,
                   reduction_use = "pca",
                   reduction_save = "UMAP",
                   dims_use = NULL,
                   n_jobs=1,
                   n_components=as.integer(2),
                   random.seed=as.integer(42)) {
  object <- ReductionBridge(object,
                            reduction_use = reduction_use,
                            reduction_save = reduction_save,
                            function_use = reduction_save,
                            dims_use = dims_use,
                            perplexity = NULL,
                            n_jobs=n_jobs,
                            n.components=n_components,
                            seed=random.seed)
  SetcalcParams <- function(object, calculation, time = TRUE, ...) {
    object@calc.params[calculation] <- list(...)
    object@calc.params[[calculation]]$object <- NULL
    object@calc.params[[calculation]]$object2 <- NULL
    if(time) {
      object@calc.params[[calculation]]$time <- Sys.time()
    }
    return(object)
  }
  parameters.to.store <- as.list(environment(), all = TRUE)[names(formals("DoUMAP"))]
  object <- SetcalcParams(object = object, calculation = "DoUMAP", ... = parameters.to.store)
  return(object)
}

#' @title DoFItSNE
#'
#' @description Perform FItSNE dimentional reduction
#'
#' @param object A Seurat or SingleCellExperiment object to be transformed.
#' @param reduction_use Prior dimensional reduction to use for calculations
#' (i.e. pca, ica, cca, etc...). Default: pca
#' @param reduction_save Name to use for the reduction. Default: FItSNE
#' @param dims_use Dimensions from `reduction_use`
#' @param n_jobs number of workers
#' @param perplexity perplexity parameter of tSNE.
#' @param n_components number of reduced dimentions
#' @param random.seed random seed for initialization of dimentional reduction
#' @param max_iter maximum iteration for FItSNE embeddings. default=1000
#' @param df Degree of freedom of t-distribution, must be greater than 0.
#' Values smaller than 1 correspond to heavier tails, which can often
#' resolve substructure in the embedding. See Kobak et al. (2019) for details
#'
#' @importFrom glue glue
#' @importFrom reticulate import py_module_available py_set_seed
#' @rdname DoFItSNE
#' @export
#'
DoFItSNE <- function(object,
                   reduction_use = "pca",
                   reduction_save = "FItSNE",
                   dims_use = NULL,
                   n_jobs=1,
                   perplexity=40.0,
                   n_components=as.integer(2),
                   random.seed=as.integer(42),
                   max_iter=as.integer(1000),
                   df=1) {
  if (object@version == "2.3.4"){
    if (is.element(reduction_use, names(object@dr))) {
      cell_embeddings <- object@dr$pca@cell.embeddings
    } else {
      message(glue::glue("{reduction_use} has not yet been performed"))
      stop()
    }
  } else if (object@version >= "3.0"){
    if (is.element(reduction_use, names(object@reductions))) {
      cell_embeddings = Seurat::Embeddings(object@reductions$pca)
    } else {
      message(glue::glue("{reduction_use} has not yet been performed"))
      stop()
    }

  }
  if (!reticulate::py_module_available("fitsne")){
    stop("The fitsne module is unavailable.  Please activate the appropriate environment or install the module.")
  }
  fitsne.module <- reticulate::import(module = "fitsne", delay_load = TRUE)
  cell_embeddings=cell_embeddings[,dims_use]
  py_array <- reticulate::np_array(data = cell_embeddings, order = "C")
  py_set_seed(as.integer(random.seed), disable_hash_randomization = TRUE)
  fitsne.embed <- fitsne.module$FItSNE(X = py_array,
                                       no_dims=as.integer(2),
                                       #theta=0.5,
                                       perplexity=perplexity,
                                       max_iter=as.integer(max_iter),
                                       fft_not_bh=TRUE,
                                       ann_not_vptree=TRUE,
                                       #stop_early_exag_iter=as.integer(250),
                                       #K=as.integer(-1),
                                       #sigma=-30,
                                       #mom_switch_iter=as.integer(250),
                                       #momentum=0.5,
                                       #final_momentum=0.8,
                                       learning_rate=as.integer(round(nrow(cell_embeddings)/12,0)),
                                       #early_exag_coeff=as.integer(12),
                                       no_momentum_during_exag=FALSE,
                                       #n_trees=as.integer(50),
                                       #search_k=as.integer(-1),
                                       #start_late_exag_iter=as.integer(-1),
                                       #late_exag_coeff=-1,
                                       #nterms=as.integer(3),
                                       #intervals_per_integer=as.integer(1),
                                       #min_num_intervals=as.integer(50),
                                       rand_seed=as.integer(random.seed),
                                       #initialization=NULL,
                                       df=df,
                                       nthreads=as.integer(n_jobs))
  SetcalcParams <- function(object, calculation, time = TRUE, ...) {
    object@calc.params[calculation] <- list(...)
    object@calc.params[[calculation]]$object <- NULL
    object@calc.params[[calculation]]$object2 <- NULL
    if(time) {
      object@calc.params[[calculation]]$time <- Sys.time()
    }
    return(object)
  }
  parameters.to.store <- as.list(environment(), all = TRUE)[names(formals("DoFItSNE"))]
  object <- SetcalcParams(object = object, calculation = "DoFItSNE", ... = parameters.to.store)
  object <- PushData(
    object = object,
    python_df =  fitsne.embed,
    reduction_use = reduction_use,
    reduction_save = reduction_save,
    dims_use = dims_use)
  return(object)
}

#' Visualize 'features' on a dimensional reduction plot
#'
#' Colors single cells on a dimensional reduction plot according to a 'feature'
#' (i.e. gene expression, PC scores, number of genes detected, etc.)
#'
#' @param object Seurat object
#' @param features.plot Vector of features to plot
#' @param min.cutoff Vector of minimum cutoff values for each feature, may specify quantile in the form of 'q##' where '##' is the quantile (eg, 1, 10)
#' @param max.cutoff Vector of maximum cutoff values for each feature, may specify quantile in the form of 'q##' where '##' is the quantile (eg, 1, 10)
#' @param dim.1 Dimension for x-axis (default 1)
#' @param dim.2 Dimension for y-axis (default 2)
#' @param cells.use Vector of cells to plot (default is all cells)
#' @param pt.size Adjust point size for plotting
#' @param cols.use The two colors to form the gradient over. Provide as string vector with
#' the first color corresponding to low values, the second to high. Also accepts a Brewer
#' color scale or vector of colors. Note: this will bin the data into number of colors provided.
#' @param pch.use Pch for plotting
#' @param reduction.use Which dimensionality reduction to use. Default is
#' "tsne", can also be "pca", or "ica", assuming these are precomputed.
#' @param nCol Number of columns to use when plotting multiple features.
#' @param no.axes Remove axis labels
#' @param no.legend Remove legend from the graph. Default is TRUE.
#' @param coord.fixed Use a fixed scale coordinate system (for spatial coordinates). Default is FALSE.
#' @param do.return return the ggplot2 object
#' @param threads number of threads for plot generation
#' @param do.par perform parallel processing of not
#' @param plot.save if exported polts are saved to file or not
#' @param dir.save plot file output directory
#'
#'
#' @return return a list of ggplot2 object
#'
#' @export
#'
#'
FeaturePlot2 <- function(
  object,
  features.plot,
  min.cutoff = NA,
  max.cutoff = NA,
  dim.1 = 1,
  dim.2 = 2,
  cells.use = NULL,
  pt.size = 1,
  cols.use = c("yellow", "red"),
  pch.use = 16,
  reduction.use = "tsne",
  nCol = NULL,
  no.axes = FALSE,
  no.title = FALSE,
  no.legend = TRUE,
  coord.fixed = FALSE,
  do.return = FALSE,
  threads = 4,
  do.par=TRUE,
  plot.save = FALSE,
  dir.save = "./"
) {
  cells.use <- SetIfNull(x = cells.use, default = colnames(x = object@data))
  if (is.null(x = nCol)) {
    nCol <- 2
    if (length(x = features.plot) == 1) {
      nCol <- 1
    }
    if (length(x = features.plot) > 6) {
      nCol <- 3
    }
    if (length(x = features.plot) > 9) {
      nCol <- 4
    }
  }
  num.row <- floor(x = length(x = features.plot) / nCol - 1e-5) + 1
  par(mfrow = c(num.row, nCol))
  dim.code <- Seurat::GetDimReduction(
    object = object,
    reduction.type = reduction.use,
    slot = 'key'
  )
  dim.codes <- paste0(dim.code, c(dim.1, dim.2))
  data.plot <- as.data.frame(Seurat::GetCellEmbeddings(
    object = object,
    reduction.type = reduction.use,
    dims.use = c(dim.1, dim.2),
    cells.use = cells.use
  ))
  x1 <- paste0(dim.code, dim.1)
  x2 <- paste0(dim.code, dim.2)
  data.plot$x <- data.plot[, x1]
  data.plot$y <- data.plot[, x2]
  data.plot$pt.size <- pt.size
  names(x = data.plot) <- c('x', 'y')
  data.use <- t(x = Seurat::FetchData(
    object = object,
    vars.all = features.plot,
    cells.use = cells.use,
    use.imputed = FALSE
  ))
  #   Check mins and maxes
  min.cutoff <- mapply(
    FUN = function(cutoff, feature) {
      ifelse(
        test = is.na(x = cutoff),
        yes = min(data.use[feature, ]),
        no = cutoff
      )
    },
    cutoff = min.cutoff,
    feature = features.plot
  )
  max.cutoff <- mapply(
    FUN = function(cutoff, feature) {
      ifelse(
        test = is.na(x = cutoff),
        yes = max(data.use[feature, ]),
        no = cutoff
      )
    },
    cutoff = max.cutoff,
    feature = features.plot
  )
  check_lengths = unique(x = vapply(
    X = list(features.plot, min.cutoff, max.cutoff),
    FUN = length,
    FUN.VALUE = numeric(length = 1)
  ))
  if (length(x = check_lengths) != 1) {
    stop('There must be the same number of minimum and maximum cuttoffs as there are features')
  }
  if(!dir.exists(dir.save)){
    dir.create(dir.save)
  }

  pList=NULL
  if(do.par){
  cl = parallel::makeCluster(threads, type="PSOCK", useXDR=FALSE)
  doParallel::registerDoParallel(cl)
  if (do.return){
  pList = foreach (j = 1:length(features.plot),
           .packages=c("ggplot2", "Seurat", "grDevices", "graphics", "RColorBrewer"),
           .noexport=setdiff(ls(),
                             c("features.plot", "SingleFeaturePlot", "coord.fixed",
                               "min.cutoff", "max.cutoff", "data.use", "data.plot",
                               "pt.size", "pch.use", "cols.use", "dim.codes","no.title",
                               "no.axes", "no.legend", "dir.save", "plot.save", "do.return"))
    ) %dopar% {
    SingleFeaturePlot2(feature=features.plot[j],
                             min.cutoff = min.cutoff[j],
                             max.cutoff = max.cutoff[j],
                             coord.fixed = coord.fixed,
                             data.use = data.use,
                             data.plot = data.plot,
                             pt.size = pt.size,
                             pch.use = pch.use,
                             cols.use = cols.use,
                             dim.codes = dim.codes,
                             no.axes = no.axes,
                             no.title = no.title,
                             no.legend = no.legend,
                             dir.save = dir.save,
                             plot.save=plot.save,
                             do.return=do.return)
    }
  } else {
    foreach (j = 1:length(features.plot),
                     .packages=c("ggplot2", "Seurat", "grDevices", "graphics", "RColorBrewer"),
                     .noexport=setdiff(ls(),
                                       c("features.plot", "SingleFeaturePlot", "coord.fixed",
                                         "min.cutoff", "max.cutoff", "data.use", "data.plot",
                                         "pt.size", "pch.use", "cols.use", "dim.codes","no.title",
                                         "no.axes", "no.legend", "dir.save", "plot.save","do.return"))
    ) %dopar% {
      SingleFeaturePlot2(feature=features.plot[j],
                         min.cutoff = min.cutoff[j],
                         max.cutoff = max.cutoff[j],
                         coord.fixed = coord.fixed,
                         data.use = data.use,
                         data.plot = data.plot,
                         pt.size = pt.size,
                         pch.use = pch.use,
                         cols.use = cols.use,
                         dim.codes = dim.codes,
                         no.axes = no.axes,
                         no.title = no.title,
                         no.legend = no.legend,
                         dir.save = dir.save,
                         plot.save=plot.save,
                         do.return=do.return)
    }
  }
  parallel::stopCluster(cl)
  } else {
  pList = list()
  if (do.return){
  for (i in c(1:length(features.plot))){
    p = SingleFeaturePlot2(feature=features.plot[i],
                       min.cutoff = min.cutoff[i],
                       max.cutoff = max.cutoff[i],
                       coord.fixed = coord.fixed,
                       data.use = data.use,
                       data.plot = data.plot,
                       pt.size = pt.size,
                       pch.use = pch.use,
                       cols.use = cols.use,
                       dim.codes = dim.codes,
                       no.axes = no.axes,
                       no.legend = no.legend,
                       no.title = no.title,
                       dir.save = dir.save,
                       plot.save=plot.save,
                       do.return=do.return)
    pList[[i]] = p
  }
  } else {
    for (i in c(1:length(features.plot))){
      SingleFeaturePlot2(feature=features.plot[i],
                             min.cutoff = min.cutoff[i],
                             max.cutoff = max.cutoff[i],
                             coord.fixed = coord.fixed,
                             data.use = data.use,
                             data.plot = data.plot,
                             pt.size = pt.size,
                             pch.use = pch.use,
                             cols.use = cols.use,
                             dim.codes = dim.codes,
                             no.axes = no.axes,
                             no.legend = no.legend,
                             no.title = no.title,
                             dir.save = dir.save,
                             plot.save=plot.save,
                             do.return = do.return)
    }
  }
  }
  if (do.return){
    return(pList)
  }
}

# Plot a single feature
#
# @param data.use The data regarding the feature
# @param feature The feature to plot
# @param data.plot The data to be plotted
# @param pt.size Size of each point
# @param pch.use Shape of each point
# @param cols.use Colors to plot
# @param dim.codes Codes for the dimensions to plot in
# @param min.cutoff Minimum cutoff for data
# @param max.cutoff Maximum cutoff for data
# @param coord.fixed Use a fixed scale coordinate system (for spatial coordinates)
# @param no.axes Remove axes from plot
# @param no.legend Remove legend from plot
# @param plot.save if exported polts are saved to file or not
# @param dir.save plot file output directory
# @param do.return return ggplot object
#
# @return A ggplot2 scatterplot
#
#' @importFrom stats na.omit
#' @importFrom utils globalVariables
#
globalVariables(names = c('x', 'y', 'gene'), package = 'rDBEC', add = TRUE)
SingleFeaturePlot2 <- function(
  data.use,
  feature,
  data.plot,
  pt.size,
  pch.use,
  cols.use,
  dim.codes,
  min.cutoff,
  max.cutoff,
  coord.fixed,
  no.axes,
  no.title = FALSE,
  no.legend,
  plot.save,
  do.return,
  dir.save
) {
  data.gene <- na.omit(object = data.frame(data.use[feature, ]))
  #   Check for quantiles
  min.cutoff <- SetQuantile2(cutoff = min.cutoff, data = data.gene)
  max.cutoff <- SetQuantile2(cutoff = max.cutoff, data = data.gene)
  #   Mask any values below the minimum and above the maximum values
  data.gene <- sapply(
    X = data.gene,
    FUN = function(x) {
      return(ifelse(test = x < min.cutoff, yes = min.cutoff, no = x))
    }
  )
  data.gene <- sapply(
    X = data.gene,
    FUN = function(x) {
      return(ifelse(test = x > max.cutoff, yes = max.cutoff, no = x))
    }
  )
  data.plot$gene <- data.gene
  #   Stuff for break points
  if (length(x = cols.use) == 1) {
    brewer.gran <- RColorBrewer::brewer.pal.info[cols.use, ]$maxcolors
  } else {
    brewer.gran <- length(x = cols.use)
  }
  #   Cut points
  if (all(data.gene == 0)) {
    data.cut <- 0
  } else {
    data.cut <- as.numeric(x = as.factor(x = cut(
      x = as.numeric(x = data.gene),
      breaks = brewer.gran
    )))
  }
  data.plot$col <- as.factor(x = data.cut)
  #   Start plotting
  p <- ggplot2::ggplot(data = data.plot, mapping = aes(x = x, y = y))
  if (brewer.gran != 2) {
    if (length(x = cols.use) == 1) {
      p <- p + geom_point(
        mapping = aes(color = col),
        size = pt.size,
        shape = pch.use
      ) + scale_color_brewer(palette = cols.use)
    } else {
      p <- p + geom_point(
        mapping = aes(color = col),
        size = pt.size,
        shape = pch.use
      ) + scale_color_manual(values = cols.use)
    }
  } else {
    if (all(data.plot$gene == data.plot$gene[1])) {
      warning(paste0("All cells have the same value of ", feature, "."))
      p <- p + geom_point(color = cols.use[1], size = pt.size, shape = pch.use)
    } else {
      p <- p + geom_point(
        mapping = aes(color = gene),
        size = pt.size,
        shape = pch.use
      ) + scale_color_gradientn(
        colors = cols.use,
        guide = guide_colorbar(title = feature)
      )
    }
  }
  if (no.legend) {
    p <- p  + theme_classic() +
      theme(plot.title=element_text(hjust = 0.5), text=element_text(size=10)) +
      theme(axis.text.x=element_text(size=10), axis.text.y=element_text(size=10), legend.position = 'none')

  }
  if (no.axes) {
    p <- p + theme(
      axis.line = element_blank(),
      axis.text.x = element_blank(),
      axis.text.y = element_blank(),
      axis.ticks = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
    if (!no.title) p <- p + labs(title = feature, x ="", y="")
    if (no.title) p <- p + labs(x ="", y="")
  } else {
    if (no.title) p <- p + labs(x = dim.codes[1], y = dim.codes[2])
    if (!(no.title)) p <- p + labs(title = feature, x = dim.codes[1], y = dim.codes[2])
  }
  if(coord.fixed) {
    p <- p  + theme_classic() + coord_fixed()
  }
  if(plot.save){
    plot_name = paste(dir.save, feature, ".png", sep="")
    ggsave(filename = plot_name, plot = p, device="png", units="in", dpi = 300,
           width = 4, height = 4, limitsize=FALSE)
  }
  if(do.return){
    return(p)
  }
}

# Find the quantile of a data
#
# Converts a quantile in character form to a number regarding some data
# String form for a quantile is represented as a number prefixed with 'q'
# For example, 10th quantile is 'q10' while 2nd quantile is 'q2'
#
# Will only take a quantile of non-zero data values
#
# @param cutoff The cutoff to turn into a quantile
# @param data The data to turn find the quantile of
#
#' @importFrom stats quantile
#
# @return The numerical representation of the quantile
#
SetQuantile2 <- function(cutoff, data) {
  if (grepl(pattern = '^q[0-9]{1,2}$', x = as.character(x = cutoff), perl = TRUE)) {
    this.quantile <- as.numeric(x = sub(
      pattern = 'q',
      replacement = '',
      x = as.character(x = cutoff)
    )) / 100
    data <- unlist(x = data)
    data <- data[data > 0]
    cutoff <- stats::quantile(x = data, probs = this.quantile)
  }
  return(as.numeric(x = cutoff))
}

#' Visualize 'features' on a dimensional reduction plot
#'
#' Colors single cells on a dimensional reduction plot according to a 'feature'
#' (i.e. gene expression, PC scores, number of genes detected, etc.)
#'
#' @param object Seurat object
#' @param features.plot Vector of features to plot
#' @param ident.include Vector of identity of cells which includes
#' @param group.by meta.data name for primary grouping each Vln plot
#' @param split.by meta.data name for spliting each Vln plot
#' @param cells.use Vector of cells to plot (default is all cells)
#' @param do.return return the ggplot2 object
#' @param threads number of threads for plot generation
#' @param do.par perform parallel processing of not
#' @param plot.save if exported polts are saved to file or not
#' @param dir.save plot file output directory
#' @param type plot type (either "violin" or "box")
#' @param pt.size dot size for scatter plot on violin or box plot
#'
#'
#' @return return a list of ggplot2 object
#'
#' @export
#'
#'
VlnPlot2 <- function(
  object,
  features.plot,
  ident.include = NULL,
  group.by = NULL,
  split.by = NULL,
  cells.use = NULL,
  do.return = FALSE,
  threads = 4,
  do.par=TRUE,
  plot.save = FALSE,
  type = "violin",
  pt.size = 0.1,
  dir.save = "./"
) {
  data.use <- data.frame(Seurat::FetchData(object = object,
                                           vars.all = features.plot,
                                           use.imputed = FALSE),
                         check.names = F)
  if (!is.null(x = group.by)) {
    ident.use <- as.factor(x = Seurat::FetchData(
      object = object,
      vars.all = group.by
    )[, 1])
  } else {
    ident.use <- object@ident
  }
  if (!is.null(x = split.by)) {
    split.use <- object@meta.data[,split.by]
  } else {
    split.use <- object@meta.data[,"orig.ident"]
  }
  gene.names <- colnames(x = data.use)[colnames(x = data.use) %in% c(rownames(x = object@data), colnames(x = object@meta.data))]
  if(!dir.exists(dir.save)){
    dir.create(dir.save)
  }
  if (!is.null(x = cells.use)){
  hoge = rownames(data.use) %in% cells.use
  data.use = data.use[hoge,]
  ident.use = ident.use[hoge]
  split.use = split.use[hoge]
  }

  pList=NULL
  if(do.par){
    cl = parallel::makeCluster(threads, type="PSOCK", useXDR=FALSE)
    doParallel::registerDoParallel(cl)
    if(do.return){
    pList = foreach (j = 1:length(gene.names),
                     .packages=c("ggplot2", "Seurat", "grDevices", "graphics", "RColorBrewer"),
                     .noexport=setdiff(ls(),
                                       c("split.use", "gene.names", "ident.use","do.return",
                                         "data.use", "dir.save", "plot.save", "type", "pt.size"))
    ) %dopar% {
      SingleVlnPlot2(feature=gene.names[j],
                         data.use = data.use,
                         ident.use = ident.use,
                         split.use = split.use,
                         dir.save = dir.save,
                         plot.save=plot.save,
                         plot.type=type,
                         pt.size = pt.size,
                         do.return=do.return)
    }
    } else{
      foreach (j = 1:length(gene.names),
               .packages=c("ggplot2", "Seurat", "grDevices", "graphics", "RColorBrewer"),
               .noexport=setdiff(ls(),
                                 c("split.use", "gene.names", "ident.use","do.return",
                                   "data.use", "dir.save", "plot.save", "type", "pt.size"))
      ) %dopar% {
        SingleVlnPlot2(feature=gene.names[j],
                       data.use = data.use,
                       ident.use = ident.use,
                       split.use = split.use,
                       dir.save = dir.save,
                       plot.save=plot.save,
                       plot.type=type,
                       pt.size = pt.size,
                       do.return=do.return)
      }
    }
    parallel::stopCluster(cl)
  } else {
    if(do.return){
    pList = list()
    for (j in c(1:length(features.plot))){
      p = SingleVlnPlot2(feature=gene.names[j],
                         data.use = data.use,
                         ident.use = ident.use,
                         split.use = split.use,
                         dir.save = dir.save,
                         plot.save = plot.save,
                         plot.type=type,
                         pt.size=pt.size,
                         do.return=do.return)
      pList[[j]] = p
    }
    } else {
      for (j in c(1:length(features.plot))){
      SingleVlnPlot2(feature=gene.names[j],
                     data.use = data.use,
                     ident.use = ident.use,
                     split.use = split.use,
                     dir.save = dir.save,
                     plot.save = plot.save,
                     plot.type=type,
                     pt.size=pt.size,
                     do.return=do.return)
      }
    }
  }
  if (do.return){
    return(pList)
  }
}

# Plot a single Violin Plot
#
# @param data.use The data regarding the feature
# @param feature The feature to plot
# @param data.plot The data to be plotted
# @param pt.size Size of each point
# @param pch.use Shape of each point
# @param cols.use Colors to plot
# @param dim.codes Codes for the dimensions to plot in
# @param min.cutoff Minimum cutoff for data
# @param max.cutoff Maximum cutoff for data
# @param coord.fixed Use a fixed scale coordinate system (for spatial coordinates)
# @param no.axes Remove axes from plot
# @param no.legend Remove legend from plot
# @param plot.save if exported polts are saved to file or not
# @param dir.save plot file output directory
#
# @return A ggplot2 scatterplot
#
#' @importFrom stats na.omit
#' @importFrom utils globalVariables
#

globalVariables(names = c('orig.ident', 'ident', 'expression'), package = 'rDBEC', add = TRUE)
SingleVlnPlot2 <- function(
  feature,
  data.use,
  ident.use,
  split.use,
  dir.save,
  plot.save,
  plot.type = "violin",
  pt.size,
  do.return
) {
  data.gene = data.use[,feature, drop=F]

  #add identity informations
  data.plot = cbind(expression=data.gene,
                    ident=ident.use,
                    orig.ident=split.use)
  colnames(data.plot)=c("expression", "ident", "orig.ident")
  if(plot.type=="violin"){
  p = data.plot %>%
    ggplot2::ggplot(aes(fill=orig.ident, y=expression, x=ident)) +
    geom_violin(position="dodge", scale = "width") +
    theme_classic() +
    ggtitle(paste(feature, sep="")) +
    theme(plot.title=element_text(hjust = 0.5), text=element_text(size=8)) +
    theme(legend.key.size = unit(0.2, 'cm')) +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
  if(plot.save){
    plot_name = paste(dir.save, feature, ".png", sep="")
    ggsave(filename = plot_name, plot = p, device="png", units="in", dpi = 300,
           width = max(6, 4.5 * length(unique(ident.use)) * length(unique(split.use)) / 30),
           height = 4, limitsize=FALSE)
  }
  } else if (plot.type == "box"){
    p = data.plot %>%
      ggplot2::ggplot(aes(fill=orig.ident, y=expression, x=ident)) +
      geom_boxplot(position="dodge", outlier.shape = NA) +
      theme_classic() +
      ggtitle(paste(feature, sep="")) +
      theme(plot.title=element_text(hjust = 0.5), text=element_text(size=8)) +
      theme(legend.key.size = unit(0.2, 'cm')) +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
    if(plot.save){
      plot_name = paste(dir.save, feature, ".png", sep="")
      ggsave(filename = plot_name, plot = p, device="png", units="in", dpi = 100,
             width = max(6, 4.5 * length(unique(ident.use)) * length(unique(split.use)) / 40),
             height = 4, limitsize=FALSE)
      dev.off()
    }
  }
  if(do.return){
  return(p)
  }
}
