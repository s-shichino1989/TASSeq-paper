#' background_subtraction_wrapper
#'
#' Internal function to detect backgorund count thresholds for each gene based on
#' gaussian mixture models of lognormal count distibution (legacy version)
#'
#' @param x A sparse matrix of genes/cells count data
#' @param y rowname or rownumber of which is processed
#' @param min.count A minimum number of cells expressed for a gene to apply backgorund subtraction
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package
#' @param dir.name An output directory name for generate count threshold plots-containing folder
#'
#' @importFrom mclust Mclust emControl
#' @importFrom MASS truehist
#' @import grDevices
#' @import graphics
#' @importFrom stats density
#'
#' @rdname background_subtraction_wrapper
#' @return threshold count (raw count), single numeric value
#' @export

background_subtraction_wrapper = function(x, y,
                                          min.count=20,
                                          min.ave=5.5,
                                          min.diff=5,
                                          uncert.thre=1,
                                          dir.name="./") {
  data1 = as.numeric(x[y,])
  data1 = sort(data1[data1>0])
  data1 = log2(data1)

  if (length(data1) <= min.count) {
    thre = 0
  } else {
    data1 = data1[data1>max(data1)-12]
    data2 = try(mclust::Mclust(data1, G=1:3, modelNames="E",
                               control = mclust::emControl(itmax=1000)), silent = TRUE)
    if (class(data2) != "try-error" && class(data2) != "NULL") {
      data2_mean=sort(data2$parameters$mean)
      data2_classification=cbind(data1, data2$classification, data2$uncertainty)
      colnames(data2_classification) = c("count", "cluster", "uncertainty")
      data2_classification=as.data.frame(data2_classification)

      if (data2$G == 3){
        #if 3-component gaussian mixture
        data2_abs1=data2_mean[3]-data2_mean[1]
        data2_abs2=data2_mean[3]-data2_mean[2]
        if (data2_mean[3] >= min.ave && data2_abs2 >=min.diff){
          data3 = data2_classification[data2_classification$cluster==names(data2_mean)[2],]
          data3 = data3[data3$uncertainty<uncert.thre,1]
          if (length(data3) == 0) {
            thre = 0
          } else {
            thre = 2^max(data3)
          }
        } else if (data2_mean[3] >= min.ave && data2_abs1 >=min.diff){
          data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
          data3 = data3[data3$uncertainty<uncert.thre,1]
          if (length(data3) == 0) {
            thre = 0
          } else {
            thre = 2^max(data3)
          }
        } else {
          thre = 0
        }
      } else if (data2$G == 2 && data2_mean[2] >= min.ave && data2_mean[2]-data2_mean[1] >= min.diff) {
        #if 2-component gaussian mixture
        data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
        data3 = data3[data3$uncertainty<uncert.thre,1]
        if (length(data3) == 0) {
          thre = 0
        } else {
          thre = 2^max(data3)
        }

      } else {
        #if 1-component gaussian mixture
        thre = 0
      }
    } else {
      thre = 0
    }
  }

  if (thre != 0) {
    file.name = sprintf("%s.png", rownames(x)[y])
    file.name = paste(dir.name, "/", file.name, sep='')
    png(file.name, width = 512, height = 512)
    hoge1 = as.numeric(x[y,])
    hoge1 = sort(hoge1[hoge1>0])
    hoge1 = log2(hoge1)
    MASS::truehist(hoge1, col = "#00ffff80", border="#00ffff80",xlab = "Count(log2)", ylab = "Density",
                   main=as.character(rownames(x)[y]), xlim = c(0, ceiling(max(hoge1))), ylim =c(0,1))
    graphics::rug(hoge1, lwd=0.3)
    graphics::lines(stats::density(hoge1), type="l", col = "#0000ff80", lwd=2)
    graphics::abline(v=thre, col="red", lwd=3)
    grDevices::dev.off()
  } else {}

  return(thre)
}

#' DBEC_Biex_wrapper_hvg
#'
#' Internal function to detect backgorund count thresholds for each gene based on
#' two-component gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of count data of each gene
#' are automatically determined by flowTrans package.
#'
#' @param x A sparse matrix of genes/cells count data
#' @param y rowname or rownumber of which is processed
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak
#' @param iteration A maximum number of iteration for EM process
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package.
#'
#' @importFrom mclust Mclust emControl
#' @importFrom MASS truehist
#' @importFrom flowTrans flowTrans
#' @importFrom flowCore flowFrame
#' @import grDevices
#' @import graphics
#' @importFrom stats qt density
#'
#' @rdname DBEC_Biex_wrapper_hvg
#' @return threshold count (raw count), single numeric value
#' @export

DBEC_Biex_wrapper_hvg = function(x,
                                 y,
                                 modelnames="E",
                                 min.ave=NA,
                                 min.diff=NA,
                                 iteration = iteration,
                                 uncert.thre=0.5) {

  #apply biexponential-transformation against raw count data
  data1 = x[y,,drop=F]
  data1 = as.matrix(x[y,,drop=F])
  data2 = data1+1
  data1 = cbind(t(data1), t(data2))
  colnames(data1) = c("A", "B")
  data1 = data1[data1[,1]>0,,drop=F]
  data1 = data1[order(data1[,1]),,drop=F]
  fuga = flowCore::flowFrame(as.matrix(data1))
  fuga = try(flowTrans::flowTrans(fuga,"mclMultivBiexp", c("A", "B"),
                                  n2f=FALSE,parameters.only=FALSE), silent = TRUE)
  if (class(fuga) != "try-error" && class(fuga) != "NULL") {
    fuga = cbind(flowCore::exprs(fuga$result)[,1], data1[,1])
  } else {
    fuga = cbind(log2(data1[,1]+1), data1[,1])
  }
  data1 = fuga[,1]

  #temporary set thre object

  data2 = try(mclust::Mclust(data1, G=1:2, modelNames=modelnames,
                             control = mclust::emControl(itmax=iteration)), silent = TRUE)
  if (class(data2) != "try-error" && class(data2) != "NULL" && data2$G == 2) {
    data2_mean = rbind(data2$parameters$mean, data2$parameters$variance$sigmasq)
    data2_mean = data2_mean[,order(data2_mean[1,])]
    data2_sigmasq = data2_mean[2,]
    data2_mean = data2_mean[1,]
    t = abs(qt(0.05/2, length(data2)-1)) #t statistics of 95% CI
    data2_classification = cbind(data1, data2$classification, data2$uncertainty)
    colnames(data2_classification) = c("count", "cluster", "uncertainty")
    data2_classification = as.data.frame(data2_classification)
    data2_mean_raw2 = fuga[fuga[,1]<data2_mean[2],,drop=F]
    data2_mean_raw2 = log2(max(as.numeric(data2_mean_raw2[,2]))+1)
    data2_mean_raw1 = fuga[fuga[,1]<data2_mean[1],,drop=F]
    data2_mean_raw1 = log2(max(as.numeric(data2_mean_raw1[,2]))+1)
    #if 2-component gaussian mixture
    data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
    data3 = data3[data3$uncertainty<uncert.thre,1]
    lower = data2_mean[2] - t * data2_sigmasq[2]
    upper = data2_mean[1] + t * data2_sigmasq[1]
    if (length(data3) != 0 && upper <= lower) {
      min.ave = data2_mean_raw2
      min.diff = data2_mean_raw2 - data2_mean_raw1
    }
  }

  res=as.data.frame(c(min.ave, min.diff))
  res=t(res)
  res=as.data.frame(res, row.names=rownames(x[y,]))
  colnames(res)=c("min.ave", "min.diff")
  return(res)
}


#' background_subtraction_Biex_wrapper
#'
#' Internal function to detect backgorund count thresholds for each gene based on
#' gaussian mixture models of biexponential-transformed count distibution.
#' Parameters for biexponential transformation of count data of each gene
#' are automatically determined by flowTrans package.
#'
#' @param x A sparse matrix of genes/cells count data
#' @param y rowname or rownumber of which is processed
#' @param modelnames A modelname for mclust function
#' @param min.ave A minimum mean expression (log2 raw count) of signal peak
#' @param min.diff A minimum difference of expression (log2 raw count) between means of signal peak and background peak
#' @param iteration A maximum number of iteration for EM process
#' @param uncert.thre An acceptable uncertainty for set backgound thresholds defined by mclust package.
#' @param flooring A cutoff value of gene count. default=0
#' @param dir.name An output directory name for generate count threshold plots-containing folder. Default is current working directory.
#'
#' @importFrom mclust Mclust emControl
#' @importFrom MASS truehist
#' @importFrom flowTrans flowTrans
#' @importFrom flowCore flowFrame
#' @import grDevices
#' @import graphics
#' @importFrom stats qt density
#'
#' @rdname background_subtraction_Biex_wrapper
#' @return threshold count (raw count), single numeric value
#' @export

background_subtraction_Biex_wrapper = function(x,
                                               y,
                                               modelnames="E",
                                               min.ave=6,
                                               min.diff=5.5,
                                               flooring=0,
                                               uncert.thre=0.25,
                                               iteration=3000,
                                               dir.name="./") {

  #apply biexponential-transformation against raw count data
  data1 = x[y,,drop=F]
  data1 = as.matrix(x[y,,drop=F])
  data2 = data1+1
  data1 = cbind(t(data1), t(data2))
  colnames(data1) = c("A", "B")
  data1 = data1[data1[,1]>flooring,,drop=F]
  data1 = data1[order(data1[,1]),,drop=F]
  fuga = flowCore::flowFrame(as.matrix(data1))
  fuga = try(flowTrans::flowTrans(fuga,"mclMultivBiexp", c("A", "B"), n2f=FALSE,parameters.only=FALSE), silent = TRUE)
  if (class(fuga) != "try-error" && class(fuga) != "NULL") {
    fuga = cbind(flowCore::exprs(fuga$result)[,1], data1[,1])
  } else {
    fuga = cbind(log2(data1[,1]+1), data1[,1])
  }
  data1 = fuga[,1]

  #temporary set thre object
  thre="thre"

  data2 = try(mclust::Mclust(data1, G=1:3,
                             modelNames=modelnames,
                             control = mclust::emControl(itmax=iteration)),
              silent = TRUE)
  if (class(data2) != "try-error" && class(data2) != "NULL" && data2$G == 3) {
    data2_mean = rbind(data2$parameters$mean, data2$parameters$variance$sigmasq)
    data2_mean = data2_mean[,order(data2_mean[1,])]
    data2_sigmasq = data2_mean[2,]
    data2_mean = data2_mean[1,]
    t = abs(stats::qt(0.05/2, length(data2)-1)) #t statistics of 95% CI
    data2_classification = cbind(data1, data2$classification, data2$uncertainty)
    colnames(data2_classification) = c("count", "cluster", "uncertainty")
    data2_classification = as.data.frame(data2_classification)
    data2_mean_raw3 = fuga[fuga[,1]<data2_mean[3],,drop=F]
    data2_mean_raw3 = log2(max(as.numeric(data2_mean_raw3[,2]))+1)
    data2_mean_raw2 = fuga[fuga[,1]<data2_mean[2],,drop=F]
    data2_mean_raw1 = fuga[fuga[,1]<data2_mean[1],,drop=F]
    data2_abs1 = data2_mean_raw3 - log2(max(as.numeric(data2_mean_raw1[,2]))+1)
    data2_abs2 = data2_mean_raw3 - log2(max(as.numeric(data2_mean_raw2[,2]))+1)

    if (data2_mean_raw3 >= min.ave && data2_abs2 >=min.diff){
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[2],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[3] - t * data2_sigmasq[3]
      upper = data2_mean[2] + t * data2_sigmasq[2]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    } else if (data2_mean_raw3 >= min.ave && data2_abs1 >=min.diff){
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[3] - t * data2_sigmasq[3]
      upper = data2_mean[1] + t * data2_sigmasq[1]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    }
  } else if (class(data2) != "try-error" && class(data2) != "NULL" && data2$G == 2) {
    data2_mean = rbind(data2$parameters$mean, data2$parameters$variance$sigmasq)
    data2_mean = data2_mean[,order(data2_mean[1,])]
    data2_sigmasq = data2_mean[2,]
    data2_mean = data2_mean[1,]
    t = abs(qt(0.05/2, length(data2)-1)) #t statistics of 95% CI
    data2_classification = cbind(data1, data2$classification, data2$uncertainty)
    colnames(data2_classification) = c("count", "cluster", "uncertainty")
    data2_classification = as.data.frame(data2_classification)
    data2_mean_raw2 = fuga[fuga[,1]<data2_mean[2],,drop=F]
    data2_mean_raw2 = log2(max(as.numeric(data2_mean_raw2[,2]))+1)
    data2_mean_raw1 = fuga[fuga[,1]<data2_mean[1],,drop=F]
    data2_mean_raw1 = log2(max(as.numeric(data2_mean_raw1[,2]))+1)
    if (data2_mean_raw2 >= min.ave && data2_mean_raw2-data2_mean_raw1 >= min.diff) {
      #if 2-component gaussian mixture
      data3 = data2_classification[data2_classification$cluster==names(data2_mean)[1],]
      data3 = data3[data3$uncertainty<uncert.thre,1]
      lower = data2_mean[2] - t * data2_sigmasq[2]
      upper = data2_mean[1] + t * data2_sigmasq[1]
      if (length(data3) != 0 && upper <= lower) {thre = max(as.numeric(data3))}
    }
  }
  #visulalize Biexponential-transformed count distribution and its threshold
  if (thre != "thre") {
    file.name = sprintf("%s.png", rownames(x)[y])
    file.name = paste(dir.name, "/", file.name, sep='')
    grDevices::png(file.name, width = 512, height = 512)
    MASS::truehist(fuga[,1], col = "#00ffff80", border="#00ffff80",xlab = "biex-transformed-count(log2)", ylab = "Density",
                   main=as.character(rownames(x)[y]), xlim = c(ceiling(min(fuga[,1])), ceiling(max(fuga[,1]))), ylim =c(0,1))
    graphics::rug(fuga[,1], lwd=0.3)
    graphics::lines(stats::density(fuga[,1]), type="l", col = "#0000ff80", lwd=2)
    graphics::abline(v=thre, col="red", lwd=3)
    grDevices::dev.off()
  }

  #convert Biex-transformed threshold to original count value
  if(thre != "thre"){
    thre = fuga[fuga[,1]<=thre,,drop=F]
    thre = max(as.numeric(thre[,2]))
  } else {thre=0}
  return(thre)
}
